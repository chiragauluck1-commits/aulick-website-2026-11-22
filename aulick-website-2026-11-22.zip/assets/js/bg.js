/* AULUCK background: neon sea creatures drawn in code (no photos) on one canvas behind every page.
   Creatures: betta, jellyfish, shark, whale. Starfish, octopus and ring are not drawn.
   Reduced motion: one still picture, no loop. Tab hidden: the loop pauses.
   The canvas never takes clicks (pointer-events: none) and sits under the page content. */
(() => {
"use strict";
const canvas = document.getElementById("bg");
if (!canvas || !canvas.getContext) return;
const ctx = canvas.getContext("2d");
if (!ctx) return;

const TAU = Math.PI * 2;
const clamp = (x, a, b) => (x < a ? a : x > b ? b : x);
const lerp = (a, b, t) => a + (b - a) * t;
const frac = (x) => x - Math.floor(x);
const REDUCE = window.matchMedia("(prefers-reduced-motion: reduce)");
const REST_T = 7.3; /* time shown as the still picture for reduced motion */

let W = 0, H = 0, DPR = 1, mobile = false;
let creatures = [], specks = [];
let clock = 0, last = 0, raf = 0, seed = 20261119;

function rnd() {
  seed = (seed * 1664525 + 1013904223) >>> 0;
  return seed / 4294967296;
}

/* Body outline tables: half width along the body (0 = nose, 1 = tail), as a fraction of length. */
const SHARK_HW = [[0, 0.02], [0.04, 0.085], [0.12, 0.13], [0.22, 0.14], [0.35, 0.12], [0.5, 0.1], [0.65, 0.072], [0.8, 0.042], [0.9, 0.027], [1, 0.012]];
const WHALE_HW = [[0, 0.03], [0.04, 0.12], [0.12, 0.2], [0.25, 0.235], [0.45, 0.2], [0.65, 0.13], [0.8, 0.07], [0.9, 0.04], [1, 0.02]];
const BETTA_HW = [[0, 0.03], [0.08, 0.1], [0.22, 0.13], [0.4, 0.12], [0.6, 0.06], [0.75, 0.035], [1, 0.02]];

function interp(table, s) {
  for (let i = 1; i < table.length; i++) {
    const a = table[i - 1], b = table[i];
    if (s <= b[0]) return lerp(a[1], b[1], (s - a[0]) / (b[0] - a[0] || 1));
  }
  return table[table.length - 1][1];
}

/* Sideways bend of the spine at position s (0 nose to 1 tail). Grows toward the tail. */
function bend(s, L, amp, T) {
  return L * amp * s * s * Math.sin(T - s * 4.4);
}

/* Smooth closed or open path through points (midpoint quadratic curves). */
function smoothPath(pts, close) {
  ctx.moveTo(pts[0][0], pts[0][1]);
  for (let i = 1; i < pts.length - 1; i++) {
    const mx = (pts[i][0] + pts[i + 1][0]) / 2, my = (pts[i][1] + pts[i + 1][1]) / 2;
    ctx.quadraticCurveTo(pts[i][0], pts[i][1], mx, my);
  }
  const n = pts[pts.length - 1];
  ctx.lineTo(n[0], n[1]);
  if (close) ctx.closePath();
}

/* Outline of a fish body in local coordinates (nose at +x, tail at -x). */
function bodyOutline(c, table, span, amp, T) {
  const L = c.size, N = 40, top = [], bot = [];
  for (let i = 0; i <= N; i++) {
    const s = i / N;
    const x = span * L * (0.5 - s);
    const y = bend(s, L, amp, T);
    const w = interp(table, s) * L;
    top.push([x, y - w]);
    bot.push([x, y + w]);
  }
  return top.concat(bot.reverse());
}

/* Helpers that give the edge position of the body at spine position s. */
function edgeX(s, L, span) { return span * L * (0.5 - s); }
function edgeTop(s, c, table, amp, T) { return bend(s, c.size, amp, T) - interp(table, s) * c.size; }
function edgeBot(s, c, table, amp, T) { return bend(s, c.size, amp, T) + interp(table, s) * c.size; }

/* Glow on a path: a soft outer halo, then a bright thin rim. */
function glow(color, blur, width) {
  ctx.shadowColor = color;
  ctx.shadowBlur = blur * DPR;
  ctx.lineWidth = width;
  ctx.strokeStyle = color;
  ctx.stroke();
  ctx.shadowBlur = 0;
}

/* ---------- creatures ---------- */

function drawShark(c, T) {
  const L = c.size, span = 1, amp = 0.05, table = SHARK_HW;
  const tailX = edgeX(1, L, span);
  const tailY = bend(1, L, amp, T);
  const dx = edgeX(0.92, L, span) - tailX;
  const dy = bend(0.92, L, amp, T) - tailY;
  const tilt = Math.atan2(dy, Math.abs(dx));

  /* Tail with a larger upper lobe. */
  ctx.save();
  ctx.translate(tailX, tailY);
  ctx.rotate(-tilt);
  ctx.beginPath();
  ctx.moveTo(0.02 * L, -0.03 * L);
  ctx.quadraticCurveTo(-0.1 * L, -0.04 * L, -0.2 * L, -0.2 * L);
  ctx.quadraticCurveTo(-0.16 * L, -0.06 * L, -0.13 * L, -0.01 * L);
  ctx.quadraticCurveTo(-0.1 * L, 0.03 * L, -0.16 * L, 0.13 * L);
  ctx.quadraticCurveTo(-0.06 * L, 0.05 * L, 0.02 * L, 0.03 * L);
  ctx.closePath();
  ctx.fillStyle = "#24557c";
  ctx.fill();
  glow("rgba(60,230,255,0.7)", 14, 1.6);
  ctx.restore();

  /* Dorsal fin. */
  const X = (s) => edgeX(s, L, span);
  const TP = (s) => edgeTop(s, c, table, amp, T);
  const BT = (s) => edgeBot(s, c, table, amp, T);
  ctx.beginPath();
  ctx.moveTo(X(0.3), TP(0.3) + 0.02 * L);
  ctx.quadraticCurveTo(X(0.34), TP(0.34) - 0.1 * L, X(0.38), TP(0.37) - 0.2 * L);
  ctx.quadraticCurveTo(X(0.42), TP(0.42) - 0.06 * L, X(0.46), TP(0.46) + 0.02 * L);
  ctx.closePath();
  ctx.fillStyle = "#24557c";
  ctx.fill();
  glow("rgba(60,230,255,0.7)", 14, 1.4);

  /* Pectoral fin under the body, with a slow flap. */
  const flap = Math.sin(T * 1.3) * 0.035 * L;
  ctx.beginPath();
  ctx.moveTo(X(0.19), BT(0.19) - 0.01 * L);
  ctx.quadraticCurveTo(X(0.21), BT(0.21) + 0.12 * L, X(0.3), BT(0.3) + 0.19 * L + flap);
  ctx.quadraticCurveTo(X(0.25), BT(0.25) + 0.05 * L, X(0.27), BT(0.27) - 0.01 * L);
  ctx.closePath();
  ctx.fillStyle = "#3f7aa3";
  ctx.fill();
  glow("rgba(60,230,255,0.75)", 14, 1.4);

  /* Body: dark blue back, pale belly. */
  const pts = bodyOutline(c, table, span, amp, T);
  const g = ctx.createLinearGradient(0, -0.16 * L, 0, 0.16 * L);
  g.addColorStop(0, "#173f60");
  g.addColorStop(0.45, "#4f85ad");
  g.addColorStop(0.66, "#c3e0ee");
  g.addColorStop(1, "#eef8ff");
  ctx.beginPath();
  smoothPath(pts, true);
  ctx.fillStyle = g;
  ctx.fill();
  glow("rgba(60,230,255,0.95)", 16, 2.2);

  /* Gill slits, mouth and eye. */
  ctx.strokeStyle = "rgba(8,28,44,0.45)";
  ctx.lineWidth = 1.2;
  for (const s of [0.27, 0.3, 0.33, 0.36]) {
    ctx.beginPath();
    ctx.moveTo(X(s), TP(s) + 0.05 * L);
    ctx.lineTo(X(s) - 0.005 * L, TP(s) + 0.17 * L);
    ctx.stroke();
  }
  ctx.beginPath();
  ctx.moveTo(X(0.0) + 0.01 * L, bend(0.05, L, amp, T) + 0.035 * L);
  ctx.quadraticCurveTo(X(0.05), bend(0.07, L, amp, T) + 0.05 * L, X(0.11), bend(0.1, L, amp, T) + 0.03 * L);
  ctx.strokeStyle = "rgba(8,28,44,0.55)";
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(X(0.085), bend(0.085, L, amp, T) - 0.035 * L, 0.018 * L, 0, TAU);
  ctx.fillStyle = "#04121c";
  ctx.fill();
  ctx.beginPath();
  ctx.arc(X(0.085) + 0.005 * L, bend(0.085, L, amp, T) - 0.04 * L, 0.005 * L, 0, TAU);
  ctx.fillStyle = "rgba(230,250,255,0.85)";
  ctx.fill();
}

function drawWhale(c, T) {
  const L = c.size, span = 0.96, amp = 0.03, table = WHALE_HW;
  const tailX = edgeX(1, L, span);
  const tailY = bend(1, L, amp, T);
  const dx = edgeX(0.92, L, span) - tailX;
  const dy = bend(0.92, L, amp, T) - tailY;
  const tilt = Math.atan2(dy, Math.abs(dx));
  const X = (s) => edgeX(s, L, span);
  const TP = (s) => edgeTop(s, c, table, amp, T);
  const BT = (s) => edgeBot(s, c, table, amp, T);

  /* Flukes, with a notch in the middle. */
  ctx.save();
  ctx.translate(tailX, tailY);
  ctx.rotate(-tilt);
  ctx.beginPath();
  ctx.moveTo(0.02 * L, -0.02 * L);
  ctx.quadraticCurveTo(-0.08 * L, -0.02 * L, -0.13 * L, -0.17 * L);
  ctx.quadraticCurveTo(-0.08 * L, -0.07 * L, -0.07 * L, 0);
  ctx.quadraticCurveTo(-0.08 * L, 0.07 * L, -0.13 * L, 0.15 * L);
  ctx.quadraticCurveTo(-0.07 * L, 0.04 * L, 0.02 * L, 0.02 * L);
  ctx.closePath();
  ctx.fillStyle = "#1d4c7a";
  ctx.fill();
  glow("rgba(100,225,255,0.7)", 14, 1.5);
  ctx.restore();

  /* Small back hump. */
  ctx.beginPath();
  ctx.moveTo(X(0.3), TP(0.3) + 0.02 * L);
  ctx.quadraticCurveTo(X(0.35), TP(0.35) - 0.07 * L, X(0.4), TP(0.4) + 0.01 * L);
  ctx.closePath();
  ctx.fillStyle = "#1d4c7a";
  ctx.fill();
  glow("rgba(100,225,255,0.7)", 14, 1.2);

  /* Broad pectoral fin with a slow sway. */
  const sway = Math.sin(T * 0.9 + 1.2) * 0.03 * L;
  ctx.beginPath();
  ctx.moveTo(X(0.13), BT(0.13) - 0.01 * L);
  ctx.quadraticCurveTo(X(0.15), BT(0.15) + 0.14 * L, X(0.22), BT(0.22) + 0.22 * L + sway);
  ctx.quadraticCurveTo(X(0.2), BT(0.2) + 0.06 * L, X(0.23), BT(0.23) - 0.01 * L);
  ctx.closePath();
  ctx.fillStyle = "#2f6e98";
  ctx.fill();
  glow("rgba(100,225,255,0.75)", 14, 1.4);

  /* Body: deep blue back, pale belly. */
  const pts = bodyOutline(c, table, span, amp, T);
  const g = ctx.createLinearGradient(0, -0.2 * L, 0, 0.2 * L);
  g.addColorStop(0, "#143863");
  g.addColorStop(0.5, "#3d86b6");
  g.addColorStop(0.8, "#a8dcee");
  g.addColorStop(1, "#e6f8ff");
  ctx.beginPath();
  smoothPath(pts, true);
  ctx.fillStyle = g;
  ctx.fill();
  glow("rgba(100,225,255,0.95)", 16, 2.2);

  /* Throat grooves, eye and a soft highlight on the back. */
  ctx.strokeStyle = "rgba(10,40,70,0.22)";
  ctx.lineWidth = 1;
  for (let i = 0; i < 4; i++) {
    const s = 0.05 + i * 0.04;
    ctx.beginPath();
    ctx.moveTo(X(s), BT(s) - 0.03 * L);
    ctx.lineTo(X(s + 0.08), BT(s + 0.08) - 0.04 * L);
    ctx.stroke();
  }
  ctx.beginPath();
  ctx.arc(X(0.1), bend(0.1, L, amp, T) - 0.05 * L, 0.014 * L, 0, TAU);
  ctx.fillStyle = "#04121c";
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(X(0.04), TP(0.04) + 0.08 * L);
  ctx.quadraticCurveTo(X(0.2), TP(0.2) + 0.04 * L, X(0.4), TP(0.4) + 0.05 * L);
  ctx.strokeStyle = "rgba(200,240,255,0.18)";
  ctx.lineWidth = 3;
  ctx.stroke();
}

function drawBetta(c, T) {
  const L = c.size, span = 0.42, amp = 0.07, table = BETTA_HW;
  const X = (s) => edgeX(s, L, span);
  const TP = (s) => edgeTop(s, c, table, amp, T);
  const BT = (s) => edgeBot(s, c, table, amp, T);
  const ox = X(1), oy = bend(1, L, amp, T);

  /* Flowing tail fan with rays that ripple. */
  const n = mobile ? 7 : 9, tips = [];
  for (let k = 0; k < n; k++) {
    const a = -0.8 + (1.6 * k) / (n - 1) + 0.12 * Math.sin(T * 1.8 + k * 0.7);
    const r = 0.5 * L * (0.82 + 0.18 * Math.sin(k * 1.3 + T * 0.9));
    tips.push([ox - Math.cos(a) * r, oy + Math.sin(a) * r]);
  }
  ctx.beginPath();
  ctx.moveTo(ox, oy);
  ctx.lineTo(tips[0][0], tips[0][1]);
  for (let k = 0; k < n - 1; k++) {
    const mx = (tips[k][0] + tips[k + 1][0]) / 2, my = (tips[k][1] + tips[k + 1][1]) / 2;
    ctx.quadraticCurveTo(ox + (mx - ox) * 1.08, oy + (my - oy) * 1.08, tips[k + 1][0], tips[k + 1][1]);
  }
  ctx.closePath();
  const fg = ctx.createRadialGradient(ox, oy, 0, ox, oy, 0.55 * L);
  fg.addColorStop(0, "rgba(155,92,255,0.6)");
  fg.addColorStop(1, "rgba(40,200,255,0.35)");
  ctx.fillStyle = fg;
  ctx.fill();
  glow("rgba(155,120,255,0.8)", 12, 1.2);
  ctx.strokeStyle = "rgba(210,225,255,0.3)";
  ctx.lineWidth = 0.8;
  for (const t of tips) {
    ctx.beginPath();
    ctx.moveTo(ox, oy);
    ctx.lineTo(t[0], t[1]);
    ctx.stroke();
  }

  /* Long dorsal and anal fins that wave along the body. */
  for (const side of [-1, 1]) {
    const edge = side < 0 ? TP : BT;
    const pts = [];
    const M = 12;
    for (let i = 0; i <= M; i++) {
      const s = 0.15 + (0.7 * i) / M;
      const h = 0.13 * L * Math.sin((Math.PI * (s - 0.15)) / 0.7) * (1 + 0.12 * Math.sin(T * 2 - s * 6));
      pts.push([X(s), edge(s) + side * h]);
    }
    ctx.beginPath();
    smoothPath(pts.concat(Array.from({length: M + 1}, (_, i) => {
      const s = 0.85 - (0.7 * i) / M;
      return [X(s), edge(s)];
    })), true);
    ctx.fillStyle = "rgba(120,80,255,0.35)";
    ctx.fill();
    glow("rgba(120,220,255,0.6)", 10, 0.9);
  }

  /* Body with a violet-to-cyan glow. */
  const pts = bodyOutline(c, table, span, amp, T);
  const g = ctx.createLinearGradient(X(0), 0, X(1), 0);
  g.addColorStop(0, "#2ad8ff");
  g.addColorStop(0.5, "#7d5cff");
  g.addColorStop(1, "#b48cff");
  ctx.beginPath();
  smoothPath(pts, true);
  ctx.fillStyle = g;
  ctx.fill();
  glow("rgba(150,120,255,0.9)", 14, 1.6);

  ctx.beginPath();
  ctx.arc(X(0.08), bend(0.08, L, amp, T) - 0.02 * L, 0.02 * L, 0, TAU);
  ctx.fillStyle = "#04121c";
  ctx.fill();
}

function drawJelly(c, T) {
  const R = c.size;
  const p = (Math.sin(T * 1.5 + c.ph) + 1) / 2;
  const hb = R * (1 - 0.1 * p), wb = R * (1 + 0.06 * p);
  const base = 0.1 * R;
  const xs = [wb, 0.5 * wb, 0, -0.5 * wb, -wb];

  /* Tentacles behind the bell. */
  const n = mobile ? 5 : 7;
  for (let i = 0; i < n; i++) {
    const x0 = lerp(-0.85 * wb, 0.85 * wb, n > 1 ? i / (n - 1) : 0.5);
    const len = R * (2.2 + 0.6 * frac(i * 0.37 + c.ph));
    const pts = [];
    for (let k = 0; k <= 12; k++) {
      const s = k / 12;
      pts.push([x0 + R * 0.22 * Math.sin(T * 1.7 + s * 6 + i) * s, base + s * len]);
    }
    ctx.beginPath();
    ctx.moveTo(pts[0][0], pts[0][1]);
    for (const q of pts) ctx.lineTo(q[0], q[1]);
    ctx.strokeStyle = "rgba(120,240,255,0.07)";
    ctx.lineWidth = 4;
    ctx.stroke();
    ctx.strokeStyle = "rgba(130,245,255,0.45)";
    ctx.lineWidth = 1.1;
    ctx.stroke();
  }

  /* Bell: soft cyan dome with a scalloped rim. */
  ctx.beginPath();
  ctx.moveTo(-wb, base);
  ctx.bezierCurveTo(-wb, base - hb * 1.3, wb, base - hb * 1.3, wb, base);
  for (let i = 0; i < 4; i++) {
    ctx.quadraticCurveTo((xs[i] + xs[i + 1]) / 2, base + 0.25 * R, xs[i + 1], base);
  }
  ctx.closePath();
  const bg = ctx.createRadialGradient(0, -0.3 * R, 0, 0, -0.3 * R, 1.2 * R);
  bg.addColorStop(0, "rgba(170,250,255,0.45)");
  bg.addColorStop(0.6, "rgba(60,170,255,0.18)");
  bg.addColorStop(1, "rgba(40,90,220,0.05)");
  ctx.fillStyle = bg;
  ctx.fill();
  glow("rgba(90,240,255,0.9)", 14, 1.6);

  ctx.beginPath();
  ctx.ellipse(0, -0.35 * R, 0.35 * wb, 0.2 * hb, 0, 0, TAU);
  ctx.fillStyle = "rgba(230,255,255,0.22)";
  ctx.fill();
}

function drawCreature(c, t) {
  const p = posOf(c, t);
  ctx.save();
  ctx.translate(p.x, p.y);
  ctx.scale(c.dir, 1);
  ctx.rotate(p.ang);
  if (c.kind === "shark") drawShark(c, t);
  else if (c.kind === "whale") drawWhale(c, t);
  else if (c.kind === "betta") drawBetta(c, t);
  else drawJelly(c, t);
  ctx.restore();
}

/* Position: each creature crosses the screen once per cycle and wraps off-screen. */
function posOf(c, t) {
  const m = c.size * 0.9;
  const u = frac(c.off + t / c.dur);
  const x = c.dir > 0 ? lerp(-m, W + m, u) : lerp(W + m, -m, u);
  const w = TAU * c.fy;
  const y = H * (c.y0 + c.ay * Math.sin(w * t + c.ph));
  const dxdt = ((W + 2 * m) / c.dur);
  const dydt = H * c.ay * w * Math.cos(w * t + c.ph);
  const ang = clamp(0.6 * Math.atan2(dydt, dxdt), -0.25, 0.25);
  return {x, y, ang};
}

function makeCreature(kind, i) {
  const c = {kind, dir: i % 2 ? -1 : 1, ph: rnd() * TAU, off: rnd(), y0: 0.1 + rnd() * 0.8,
    ay: 0.03 + rnd() * 0.04, fy: 0.012 + rnd() * 0.018};
  if (kind === "shark") { c.size = clamp(W * (mobile ? 0.7 : 0.42), 170, 580); c.dur = 62 + rnd() * 14; }
  else if (kind === "whale") { c.size = clamp(W * (mobile ? 0.62 : 0.36), 150, 500); c.dur = 80 + rnd() * 14; }
  else if (kind === "betta") { c.size = clamp(W * (mobile ? 0.42 : 0.22), 90, 260); c.dur = 34 + rnd() * 12; }
  else { c.size = clamp(W * (mobile ? 0.09 : 0.055), 20, 72); c.dur = 60 + rnd() * 30; }
  return c;
}

function build() {
  mobile = W < 768;
  seed = 20261119;
  const plan = mobile ? ["betta", "jelly", "shark", "whale", "betta", "jelly"]
                      : ["betta", "jelly", "shark", "whale", "betta", "jelly", "betta"];
  creatures = plan.map((kind, i) => makeCreature(kind, i));
  specks = [];
  const n = mobile ? 26 : 60;
  for (let i = 0; i < n; i++) {
    specks.push({x: rnd(), y: rnd(), r: 0.4 + rnd() * 1.1, a: 0.15 + rnd() * 0.45, sp: 0.004 + rnd() * 0.01, tw: rnd() * TAU});
  }
}

function draw(t) {
  ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
  ctx.fillStyle = "#050609";
  ctx.fillRect(0, 0, W, H);
  for (const s of specks) {
    const y = frac(s.y - t * s.sp);
    ctx.globalAlpha = s.a * (0.6 + 0.4 * Math.sin(t * 0.8 + s.tw));
    ctx.beginPath();
    ctx.arc(s.x * W, y * H, s.r, 0, TAU);
    ctx.fillStyle = "#cfe3ff";
    ctx.fill();
  }
  ctx.globalAlpha = 1;
  for (const c of creatures) drawCreature(c, t);
}

function layout() {
  W = document.documentElement.clientWidth || window.innerWidth;
  H = window.innerHeight;
  DPR = Math.min(window.devicePixelRatio || 1, 1.5);
  canvas.width = Math.round(W * DPR);
  canvas.height = Math.round(H * DPR);
  build();
  draw(REDUCE.matches ? REST_T : clock);
}

function loop(now) {
  raf = 0;
  const dt = last ? Math.min(0.05, (now - last) / 1000) : 0;
  last = now;
  clock += dt;
  draw(clock);
  raf = requestAnimationFrame(loop);
}

function start() {
  if (REDUCE.matches || raf || document.hidden) return;
  last = 0;
  raf = requestAnimationFrame(loop);
}

function stop() {
  if (raf) cancelAnimationFrame(raf);
  raf = 0;
}

function sync() {
  if (REDUCE.matches) { stop(); draw(REST_T); }
  else start();
}

let resizeTimer = 0;
window.addEventListener("resize", () => {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(layout, 120);
});
document.addEventListener("visibilitychange", () => {
  if (document.hidden) stop(); else sync();
});
if (REDUCE.addEventListener) REDUCE.addEventListener("change", () => { layout(); sync(); });

layout();
if (document.readyState === "complete") sync();
else window.addEventListener("load", sync);
})();
