# AULUCK Website - Checklist (v2, 22 Nov 2026)

How to use: each line is a yes/no check. Tick it only after looking at the real page at the widths listed in BLUEPRINT.md section 18 (1440, 1024, 930, 768, 390 px). Items marked "confirm" wait for Chirag.

---

## A. Member complaints (must all pass)

- [ ] **Diagram is LARGE and full width.** It fills the content width on a computer and is tall enough that every label reads at normal size. No label is smaller than body text.
- [ ] **Diagram has exactly 4 steps.** AULUCK; Business / Education; divisions; the step-4 boxes as drawn in the approved diagram. No "All Services" box inside the diagram.
- [ ] **Diagram has all category names.** Business: Solutions, Marketing, Print Media, Branding. Education: Career, Help, Knowledge. Step 4 names match the services list (see confirm item in section 17 of BLUEPRINT).
- [ ] **Diagram caption says the real site opens one level per click.**
- [ ] **Diagram controls present:** Show full diagram, Fit to screen, Zoom +, Zoom -, Reset, Back, Full screen, and a breadcrumb.
- [ ] **Business branch is blue and Education branch is purple,** with glowing connectors and arrows.
- [ ] **Services are NOT just a few sample boxes.** Business and Education lists show the full grouped list (division > category > services).
- [ ] **Services use the real names and counts:** Business 184 (38 / 107 / 19 / 20), Education 26 (5 / 4 / 17).
- [ ] **Digital Marketing is fully expanded** with all 82 services in its 9 groups.
- [ ] **Other groups show headings, counts and first items,** with a note "The full list scrolls on the site."
- [ ] **Services layout matches the sketch:** numbered boxes (1, 2, 3...) in two columns, hologram card in the centre (never the letter H), slides when needed.
- [ ] **Each service has an Enquire button.** No prices in any service list.
- [ ] **Prices appear only on the Pricing page.** Search the Home, Business, Education, About, Blogs and Founder pages for "₹" and "From" price text: none.
- [ ] **No Contact link in the header.**
- [ ] **Header has exactly 7 links in this order:** Home, Business, Education, About, Blogs, Pricing, Founder.
- [ ] **Floating round button is bottom right on every page** and opens Call and WhatsApp (+91 80596 74233).
- [ ] **Floating button never covers content** at any tested width.
- [ ] **"View Pricing" on Home scrolls to the All Services section.** On every other page it opens the Pricing page.
- [ ] **Blogs are on Home and on the Blogs page only.** Business and Education pages have no Blogs block.
- [ ] **Read full opens a pop-up on the same page** with hologram image, full text (scrollable), close X, and the Escape key closes it.
- [ ] **Background shows only betta, jellyfish, shark and whale.** No starfish, octopus or ring creature.
- [ ] **Shark and whale look solid and realistic** with an edge glow.
- [ ] **Blue ring appears only on boxes,** not in the background.
- [ ] **Every page ends with the enquiry form and the footer.**
- [ ] **Founder page is a premium profile** with a hologram and a photo placeholder if no photo is approved.

---

## B. Home page (order and content)

- [ ] Order is exactly: Hero, Large diagram, Business section, Education section, Founder, Blogs, All Services, Enquiry form, FAQ, Footer.
- [ ] Hero shows AULUCK (very large), DIGITAL MARKETING INNOVATION, the headline "We don't build brands. We engineer authority."
- [ ] Hero has "Discuss Your Project" (goes to the form) and "View Pricing" (goes to All Services).
- [ ] Hero has two chips: Business (blue) and Education (purple).
- [ ] Business section: title, buttons All / Solutions / Marketing / Print Media / Branding, search bar, numbered boxes, full grouped list, Enquire per item, "See the full Business page" button.
- [ ] Education section: title, buttons All / Career / Help / Knowledge, search bar, numbered boxes, full grouped list (with the 8 Professional Courses and hours), Enquire per item, "See the full Education page" button.
- [ ] Founder box: photo or placeholder, name, "Founder of AULUCK", button to Founder page.
- [ ] Blogs box: buttons All / Business / Education, search, slider of cards with hologram images, Read full pop-up.
- [ ] All Services box: title, buttons All / Business / Education, search, numbered boxes, Enquire per item, no prices. Totals show 184, 26, 210.
- [ ] FAQ: 16 questions (with the changes in BLUEPRINT section 17, item 7); one answer open at a time.
- [ ] No "Podcast" question in the FAQ.

---

## C. Business page

- [ ] Title "Business" in blue; short intro; buttons "Discuss Your Project" and "View Pricing" (opens Pricing).
- [ ] Large Business-only diagram (blue), 4 steps, same controls and caption.
- [ ] Services list: All / Solutions / Marketing / Print Media / Branding buttons; search bar; numbered boxes; hologram centre card.
- [ ] Clicking a division shows its name as the section title, then its categories with full lists.
- [ ] Category counts shown: Software & Technology 13; Business Systems & Automation 11; Digital Infrastructure 9; Complete Business Setup 5; Digital Marketing 82; Offline Marketing 9; Strategy & Consulting 16; Business Stationery 4; Promotional Print 6; Large-format Print 3; Branded Merchandise 2; Print Production Coordination 4; Brand Strategy & Identity 9; Creative Design 11.
- [ ] Strategy & Consulting shows its 2 groups: Business & Marketing Consulting 8; Analytics & Research 8.
- [ ] No Blogs block on this page.
- [ ] Enquiry form and footer at the bottom.

---

## D. Education page

- [ ] Title "Education" in purple; short intro; buttons "Discuss Your Project" and "View Pricing" (opens Pricing).
- [ ] Large Education-only diagram (purple), 4 steps, same controls and caption.
- [ ] Services list: All / Career / Help / Knowledge buttons; search bar; numbered boxes; no prices.
- [ ] Career 5 items; Help 4 items; Knowledge 17 items (Professional Courses 8, Tuition & Teaching / Academic Academy 4, Exam Preparation & Learning Resources 5).
- [ ] Course hours shown: Digital Marketing 95+; AI 30; Data Analytics 20; Psychology 40; Statistics 40; Basic Computer 10; Video Editing 10; Graphic Designing "to be confirmed".
- [ ] No course fee, start date or certificate claim shown.
- [ ] Internships and Student Discounts are NOT in the lists (confirm item 5).
- [ ] No Blogs block on this page.

---

## E. About page

- [ ] Headline and story text from the master copy (no added claims).
- [ ] "Perception -> Trust -> Growth" shown as three steps.
- [ ] Five guiding lines shown (psychology, premium positioning, trust systems, conversion, AI-enhanced execution with human review).
- [ ] Process row: Discover, Define, Build, Distribute, Optimise, with the "planning stages, not guaranteed dates" line.
- [ ] "How Business and Education connect" box: short, no results claims.
- [ ] "Our Work" box says "Project examples will be added here..." and shows no fake clients, logos, testimonials, awards or numbers.
- [ ] "What AULUCK does not promise" box is present with the full wording.
- [ ] Founder teaser links to the Founder page.
- [ ] Enquiry form and footer at the bottom.

---

## F. Blogs page

- [ ] Title "Blogs"; intro; buttons All (default) / Business / Education; search bar.
- [ ] Search with no match shows: "No articles match this selection. Try a different topic."
- [ ] Featured article at the top, then cards in a grid or slider.
- [ ] Each card: hologram image, tag, title, one-line summary, Read full.
- [ ] Read full pop-up: hologram top, full text scrolls inside, X closes, Escape closes, end buttons "View Pricing" and "Enquire".
- [ ] 19 article titles match the master copy list (BLUEPRINT section 8.4). "Podcast Marketing for Businesses" is NOT shown (confirm item 8).
- [ ] Author line reads "AULUCK Knowledge Hub" only. No invented author name.
- [ ] Enquiry form and footer at the bottom.

---

## G. Pricing page

- [ ] Title "Pricing"; intro; "Prices to be confirmed by AULUCK." line; third-party costs line.
- [ ] Three tier boxes: Basic, Medium, Premium. One service per line.
- [ ] Table with buttons All / Business / Education, division and category sub-filters, Fixed price / Get Quote / All filter, search bar.
- [ ] Table has Service, Price (or Get Quote), and Enquire columns.
- [ ] Totals: 210 services; 145 fixed; 65 Get Quote (39 Business + 26 Education).
- [ ] First screen rows match the services list exactly (e.g. Business Website from ₹20,000; Domain Setup from ₹1,500; Lead Capture Systems = Get Quote).
- [ ] This is the only page with prices.
- [ ] Enquiry form and footer at the bottom.

---

## H. Founder page

- [ ] Name "Chirag Auluck", line "Founder of AULUCK", headline "The thinking behind AULUCK."
- [ ] Photo, or the placeholder "Photo to be added" if no approved photo.
- [ ] Bio uses only the safe master-copy text (BLUEPRINT section 10). No years, degrees, awards or clients.
- [ ] Philosophy: Perception -> Trust -> Growth.
- [ ] Timeline placeholder: "Timeline to be added by Chirag."
- [ ] Verified work and links: "To be added". No fake links.
- [ ] Quote area: "Quote to be added." until Chirag sends his own words.
- [ ] CTA "Discuss Your Project".
- [ ] Enquiry form and footer at the bottom.

---

## I. Enquiry form (every page)

- [ ] Fields in order: Full name (required), Business / organisation, Email (required, valid format), Phone / WhatsApp, I am enquiring about (required dropdown), Project or course details (required), Preferred contact method, Privacy consent (required), Submit Enquiry.
- [ ] No budget field.
- [ ] Submitting with a blank required field shows "Please complete this field."
- [ ] Without consent: "Please confirm that you have read the Privacy Policy and agree to be contacted about this enquiry."
- [ ] Sending state: "Submitting your enquiry..."
- [ ] Success message "Thank you. Your enquiry has been received." shows only after the enquiry really goes through.
- [ ] Error message "We could not submit your enquiry..." shows call and WhatsApp buttons. No raw error text.

---

## J. Footer (every page)

- [ ] AULUCK logo and one-line description (master copy wording).
- [ ] Page links: Home, Business, Education, About, Blogs, Pricing, Founder.
- [ ] Call and WhatsApp: +91 80596 74233.
- [ ] Email: shown only after Chirag confirms it (confirm item 1).
- [ ] Social links: "Social links to be added" placeholders only.
- [ ] Terms | Privacy | Cookie | Accessibility open pop-ups on the same page. Square-bracket placeholders stay hidden.

---

## K. Look and feel

- [ ] Colours: #050609 background, #101522 and #151A27 surfaces, #168BFF Business blue, #9B5CFF Education purple, #F4F5F7 and #B8BBC5 text.
- [ ] Font is Space Grotesk, loaded from the bundled files (no online link).
- [ ] Page titles 60-72 px; section titles about 52 px; box titles 28-34 px; body 16-18 px (desktop).
- [ ] Phone: hero 36-44 px; section titles 30-36 px; body 15-16 px.
- [ ] Text contrast at least 4.5 to 1. Box text sits on dark panels.
- [ ] No sideways scroll on any page at any tested width.
- [ ] No pink, orange or gold large areas. No rainbow gradients.

---

## L. Hologram, background and motion

- [ ] Hologram is blue, violet and cyan, never the letter H.
- [ ] Hologram appears on: Home hero, centre cards of the three lists, Founder box, blog card images, featured blog.
- [ ] Background creatures: betta, jellyfish, shark, whale only.
- [ ] Creatures loop with no visible jump.
- [ ] Background animation pauses when the tab is hidden.
- [ ] Phone shows fewer particles and lighter effects.
- [ ] Reduced-motion setting: background and hologram show a still frame; nothing shakes, spins or flashes.
- [ ] Text is visible even if an animation does not run.

---

## M. Music (proposal, confirm item 2)

- [ ] Sound is OFF when the page opens.
- [ ] Clear SOUND ON / SOUND OFF button in the header area.
- [ ] Volume slider works.
- [ ] Fades in and out; loop has no click at the join.
- [ ] Lowers a little when a pop-up opens.
- [ ] On/off and volume remembered on the same device.
- [ ] Nothing plays until Chirag confirms the proposal.

---

## N. Images and placeholders

- [ ] Logo is the official AULUCK logo file, not redrawn or stretched.
- [ ] Images come from the existing site only where approved.
- [ ] Missing images show a labelled placeholder, never a random stock photo or fake client logo.
- [ ] Founder photo shows "Photo to be added" if none is approved.

---

## O. Content honesty (must all pass)

- [ ] No invented phone numbers, emails, clients, testimonials, awards, results, years or course prices.
- [ ] No guarantee of sales, rankings or returns anywhere on the site.
- [ ] Email is not shown until confirmed (confirm item 1).
- [ ] Podcast is not a page, not in the FAQ, and not in the blogs (confirm items 7 and 8).
- [ ] No Contact page.

---

## P. Performance and links

- [ ] The first screen appears quickly; animation starts after the page is ready.
- [ ] Images are small and lazy-loaded.
- [ ] Every button and link goes to a real place (a section, a page, a pop-up or the call/WhatsApp link).
- [ ] Call link: tel:+918059674233. WhatsApp link uses +918059674233.

---

## Q. Open items for Chirag (nothing is final until these are answered)

- [ ] Confirm item 1: correct email address.
- [ ] Confirm item 2: background music yes or no.
- [ ] Confirm item 3: single-price services in the tier boxes.
- [ ] Confirm item 4: diagram branding category names.
- [ ] Confirm item 5: Internships and Student Discounts.
- [ ] Confirm item 6: prices from the services list.
- [ ] Confirm item 7: FAQ changes.
- [ ] Confirm item 8: podcast article held back.
- [ ] Confirm item 9: blog tags.
- [ ] Confirm item 10: founder photo and details.
- [ ] Confirm item 11: social links.
- [ ] Confirm item 12: legal text checked.
- [ ] Confirm item 13: course status.
- [ ] Confirm item 14: phone number active.
