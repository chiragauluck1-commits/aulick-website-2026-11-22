# AULUCK Website - Full Plan (v2, 22 Nov 2026)

For: Chirag Auluck, and any new visitor who needs to understand the site fast.

Plain words only. Where this plan says "to confirm", nothing goes live until Chirag says yes.

---

## 1. The idea in one minute

- The site has 7 pages only: Home, Business, Education, About, Blogs, Pricing, Founder.
- AULUCK sits at the top. It splits into two sides: Business (blue) and Education (purple).
- Business has 4 divisions: Solutions, Marketing, Print Media, Branding.
- Education has 3 divisions: Career, Help, Knowledge.
- Prices show only on the Pricing page. Nowhere else.
- A visitor should know in 10 seconds what AULUCK does and where to click.
- Nothing extra. If a page or box is not in this plan, it is not built.

---

## 2. Rules for the whole site

**Pages:** exactly 7. No Contact page (the form is at the bottom of each page). No Podcast page. No Our Work page as a separate page.

**Header:** on every page (see section 3).

**Floating call/WhatsApp button:** on every page, same corner (bottom right). See section 11.3.

**Enquiry form and footer:** at the bottom of every page (see section 11).

**Prices:** only on the Pricing page. Services on Home, Business and Education show names and counts, never prices.

**"View Pricing" button:**
- On Home: it scrolls down to the All Services section.
- On every other page: it opens the Pricing page.
- It is not shown on the Pricing page itself.

**Services have no separate pages.** Each service is a row in a list. "Enquire" opens the enquiry form with that service picked.

**Background:** a moving dark sea scene with 4 creatures only (betta fish, jellyfish, shark, whale), plus a moving hologram. See section 12.

**Colours and fonts:** section 13.

**Copy:** simple English, clear for a new visitor. No invented claims, no fake clients, no fake reviews, no guarantees of sales or rankings. Site copy stays in the wording of the master copy file.

---

## 3. Header (all pages)

- Left: the official AULUCK logo (not redrawn, not distorted).
- Right: 7 links in this order:
  **Home | Business | Education | About | Blogs | Pricing | Founder**
- Sticky: it stays at the top while scrolling. Dark and slightly see-through.
- The current page is highlighted:
  - Business page: blue highlight.
  - Education page: purple highlight.
  - Other pages: white with a thin blue underline.
- No "Contact" link. No "Enquire" button in the header. (Enquiry is at the bottom of each page.)
- Phone (under 768 px): a menu button opens a full-screen list. Items are big and easy to tap.

---

## 4. Page 1 - Home

Order, top to bottom: Hero -> Large diagram -> Business section -> Education section -> Founder -> Blogs -> All Services -> Enquiry form -> FAQ -> Footer.

Blogs do NOT sit inside the Business or Education sections. Each block is one box so nothing looks cut off.

### 4.1 Hero (first screen)

- Big label: AULUCK (very large).
- Small line: DIGITAL MARKETING INNOVATION.
- Big headline: "We don't build brands. We engineer authority."
- Short text: "AULUCK brings strategy, marketing, technology, print media, branding and education together under one connected brand."
- Two buttons:
  - "Discuss Your Project" - scrolls to the enquiry form.
  - "View Pricing" - scrolls to the All Services section (rule in section 2).
- Two small chips under the text:
  - "Business - 4 divisions" (blue). Tapping it scrolls to the diagram and the Business side.
  - "Education - Career, Help, Knowledge" (purple). Same for Education.
- The background and hologram move behind this block (see section 12).

### 4.2 The big diagram

Full width. Tall enough that every label is readable at normal size. It is the approved picture from 21 Nov, made live.

**Title:** "How AULUCK is organised" (large).

**Small caption:** "The real site opens one level per click. Here all levels are open." (Tap a box to open the next step.)

**The 4 steps, top to bottom (exactly as the approved diagram; there is no fifth box):**

- Step 1: AULUCK (one wide box, dark blue to purple).
- Step 2: Business (blue) and Education (purple).
- Step 3: Business: Solutions, Marketing, Print Media, Branding. Education: Career, Help, Knowledge.
- Step 4: the approved boxes under each step-3 box, as drawn:
  - Solutions: Software & Technology; Business Systems & Automation; Digital Infrastructure; Complete Business Setup.
  - Marketing: Digital Marketing; Offline Marketing; Strategy & Consulting.
  - Print Media: Business Stationery; Promotional Print; Large-format Print; Branded Merchandise; Print Production Coordination.
  - Branding: Brand Strategy; Brand Identity; Guidelines; Brand Applications; Creative Direction.
  - Career: Industry Guides; Career Options; Career Planning; Skill Pathways; Job Guidance / Preparation; Internships.
  - Help: Scholarship Information; Scholarship Application Guidance; Student Help Desk / Support; Course / Admission Guidance; Student Discounts.
  - Knowledge: Professional Courses; Tuition & Teaching / Academic Academy; Exam Preparation & Learning Resources.
- No "All Services" box in the diagram. The All Services section lives on Home below the Business and Education sections, as the page spec says.

**Live site behaviour (for the real site):**
- Default view: AULUCK, Business and Education only (Steps 1 and 2).
- Tap AULUCK: opens Step 3.
- Tap Business or Education: opens its divisions and categories (Step 4). Blue on the Business side, purple on the Education side.
- Tap a division box (e.g. Marketing): opens its Step 4 categories only.
- Tap "Show full diagram": opens every step for both sides at once.
- Tap "Back" or the breadcrumb (e.g. AULUCK > Business > Marketing) to go up one step.

**Controls row:** Show full diagram | Fit to screen | Zoom + | Zoom - | Reset | Back | Full screen.

**Lines and arrows:**
- Glowing lines go from each parent box down to its children.
- Each line ends in a small arrow pointing to the child.
- Blue lines on the Business side, purple on the Education side.

**Box rules:**
- All boxes are the same size on the same level.
- Text is centred, at most 2 lines, and never runs out of the box.
- Hover or touch lights the box border a little. No flashing.

**Phone:** the diagram scrolls sideways inside its own box with swipe. The labels never shrink below a readable size.

### 4.3 Business section (Home)

- Title: "Business" (large, blue). Short line: "Four divisions. 184 services."
- Buttons: All (default) | Solutions | Marketing | Print Media | Branding.
- Search bar: "Search Business services".
- Numbered boxes (1, 2, 3...) in two columns with the hologram card in the centre, same layout as section 5.3.
- Full grouped list: every division > category > its services, with counts (e.g. "Digital Marketing: 82 services"). Digital Marketing is shown fully expanded. Other groups are headed groups with counts and first items. A note: "The full list scrolls on the site."
- Enquire button on each item. No prices.
- Button: "See the full Business page" -> Business page.

### 4.4 Education section (Home)

Same pattern, in purple.

- Title: "Education" (large, purple). Short line: "Three groups. 26 services."
- Buttons: All (default) | Career | Help | Knowledge.
- Search bar: "Search Education services".
- Numbered boxes in two columns with the hologram card in the centre.
- Full grouped list (section 6.3), including the Professional Courses with their hours.
- Enquire button on each item. No prices.
- Button: "See the full Education page" -> Education page.

**Layout rule for both sections (Home, Business, Education):**
- Numbered boxes are shown two columns at a time, with the hologram card between them on a computer.
- If they do not fit, the boxes slide left and right with arrows or swipe. Two columns stay on screen.
- On a phone: one column, with the list scrolling inside its box.

### 4.5 Founder (one box)

- One box with: a photo (or a clear placeholder if no photo yet), the name "Chirag Auluck", the line "Founder of AULUCK", and a premium profile look with a hologram beside it.
- Short intro (from the master copy, section 10).
- Button: "Read about the founder" -> Founder page.

### 4.6 Blogs (one box)

- One box with the heading "Blogs" (large).
- Buttons: All (default), Business, Education.
- Search bar: "Search articles".
- A slider of article cards (3 visible at a time on a computer, 1 on a phone; arrows and swipe).
- Each card: a small hologram image, a tag (Business or Education), the article title, a one-line summary, and a "Read full" button.
- "Read full" opens a pop-up on the same page (section 8.3).
- The whole box fits on screen. Nothing is cut off at the edges.

### 4.7 All Services (one box, built like Blogs)

- Title: "All Services" (large). This is the section the "View Pricing" button scrolls to.
- Buttons: All (default), Business, Education.
- Search bar: "Search all services".
- Numbered boxes in two columns, hologram card in the centre, slide if needed.
- Each box: number, service name, Enquire button.
- No prices.
- Shows the real counts: Business 184, Education 26, total 210.

### 4.8 Enquiry form (one box)

- Title: "Let's talk about your project."
- Fields and rules: section 11.1.

### 4.9 FAQ (one box)

- Title: "Frequently asked questions" (large).
- Questions and answers taken word-for-word from the master copy FAQ, except the changes listed in section 17.
- Each question opens to show its answer (one at a time).
- Real content only. No made-up questions.

### 4.10 Footer

See section 11.2.

**Length rule for Home:** each block is one screen or less on a computer after the hero. Lists sit inside their own scrolling boxes so the page stays readable.

---

## 5. Page 2 - Business

### 5.1 Top of the page

- Title: "Business" (very large, blue).
- Short intro: "Four connected divisions help a business get seen, trusted and chosen. Solutions, Marketing, Print Media and Branding." (plain wording, no claims).
- Buttons: "Discuss Your Project" and "View Pricing" (opens Pricing page).

### 5.2 The Business diagram

- Same diagram as Home, showing only the Business side: AULUCK > Business > 4 divisions > their boxes (no All Services box).
- Blue lines and boxes.
- Same controls: Show full diagram, Fit to screen, zoom, reset, back, full screen.
- Same caption: "The real site opens one level per click. Here all levels are open."

### 5.3 Business services list

Title for the whole section: "Business services" (large).

**Buttons (one row):** All (default) | Solutions | Marketing | Print Media | Branding.

**Search bar:** "Search Business services".

**Layout (per the approved sketch):**
- Numbered boxes (1, 2, 3, ...) in two columns.
- A hologram card sits in the centre, between the two columns. It is a hologram picture, never the letter H.
- If the boxes do not fit on one screen, they slide left and right.
- Each box: the number, the service name, and an "Enquire" button.
- No prices on this page.

**What "All" shows:** every division one after another. Each division has its heading, its categories, and the count (e.g. "Marketing: 107 services").

**What a division button shows:** the division name becomes the section title, then its categories with their full service lists.

**Real counts:**

| Division | Services | Categories (services) |
|---|---|---|
| Solutions | 38 | Software & Technology (13); Business Systems & Automation (11); Digital Infrastructure (9); Complete Business Setup (5) |
| Marketing | 107 | Digital Marketing (82, in 9 groups); Offline Marketing (9); Strategy & Consulting (16, in 2 groups) |
| Print Media | 19 | Business Stationery (4); Promotional Print (6); Large-format Print (3); Branded Merchandise (2); Print Production Coordination (4) |
| Branding | 20 | Brand Strategy & Identity (9); Creative Design (11) |

Total: 184 services.

**Digital Marketing (shown fully):** when Marketing is open, Digital Marketing is expanded with all 82 services in its 9 groups:
- Social Media Marketing (8)
- Search & Local Marketing (16)
- Paid Advertising & Performance (7)
- Content, Video & YouTube (16)
- Lead Generation & Conversion (8)
- Email & WhatsApp Marketing (5)
- E-Commerce Marketing (4)
- Influencer / Creator Marketing (13)
- AI-assisted Marketing Content (5)

Strategy & Consulting groups: Business & Marketing Consulting (8); Analytics & Research (8).

A small note under the list: "The full list scrolls on the site." (The list sits inside a box that scrolls, so the page stays short.)

### 5.4 Calls to action

- "Discuss Your Project" (scrolls to the form).
- "View Pricing" (opens Pricing page).

### 5.5 Bottom

- Enquiry form (section 11.1).
- Footer (section 11.2).
- No Blogs on this page.

---

## 6. Page 3 - Education

Same pattern as Business, in purple.

### 6.1 Top of the page

- Title: "Education" (very large, purple).
- Short intro: "Practical courses, career guidance, student help and learning resources." (plain wording).
- Buttons: "Discuss Your Project", "View Pricing" (opens Pricing page).

### 6.2 The Education diagram

- Education side only: AULUCK > Education > Career, Help, Knowledge > their boxes (no All Services box).
- Purple lines and boxes.
- Same controls and same caption.

### 6.3 Education list

Title: "Education" (large) with a short line: "26 services in 3 groups."

**Buttons:** All (default) | Career | Help | Knowledge.

**Search bar:** "Search Education services".

**Layout:** numbered boxes in two columns with a hologram card in the centre. Slides if needed. Enquire button in each box. No prices (Education rows are "Get Quote" items).

**Real counts:**

| Group | Services | Items |
|---|---|---|
| Career | 5 | Industry Guides; Career Options; Career Planning; Skill Pathways; Job Guidance / Preparation |
| Help | 4 | Scholarship Information; Scholarship Application Guidance; Student Help Desk / Support; Course / Admission Guidance |
| Knowledge | 17 | Professional Courses (8); Tuition & Teaching / Academic Academy (4); Exam Preparation & Learning Resources (5) |

**Courses (inside Knowledge > Professional Courses), with the real hours from the services list:**

- Digital Marketing - 95+ hours
- Artificial Intelligence (AI) - 30 hours
- Data Analytics - 20 hours
- Psychology - 40 hours
- Statistics - 40 hours
- Basic Computer - 10 hours
- Video Editing - 10 hours
- Graphic Designing - duration to be confirmed

Rule: no course fee, certificate, or start date is shown unless Chirag confirms it. Course rows say "Ask about availability" (Enquire button).

Tuition items: Class 10 Science; Class 10 Mathematics; Class 10 English / Spoken English; Classes 9 to 12 Tuition (all "Get Quote" in the services list).

Note in section 17: the approved diagram lists two Education items (Internships under Career, Student Discounts under Help) that are not in the services list. They stay out of the lists until Chirag confirms.

### 6.4 Bottom

- Enquiry form, footer. No Blogs on this page.

---

## 7. Page 4 - About

Title block:
- Headline: "A clearer system for how your business is seen, trusted and chosen." (large).
- Short text: AULUCK is a digital marketing and growth-focused brand built around one idea: businesses need more than separate marketing activities. They need a clear position, a credible identity, a useful digital experience and a steady way to reach and serve customers.

**Our approach (one box):**
- "Perception -> Trust -> Growth" (three steps, large).
- Plain line: "People form expectations from the signals a business sends: its name, visuals, website, content, responsiveness, proof and customer experience."

**What guides our work (one box, five short lines):**
- Consumer psychology: understand attention, perception, decision-making and customer context.
- Premium brand positioning: clarify what the business should be known for and why it matters.
- Digital trust systems: align the website, message, content and customer touchpoints.
- Conversion optimisation: reduce friction and make the next action clear.
- AI-enhanced execution: use relevant tools to improve production and workflows, with human review.

**Our process (one row of 5 steps):** Discover -> Define -> Build -> Distribute -> Optimise.
Under it: "These are planning stages, not guaranteed delivery dates. A schedule is agreed after the brief is understood."

**How Business and Education connect (one box):**
- Two sides of one AULUCK: Business helps a business get seen and trusted; Education builds practical skills and career learning.
- Short line only. No claims about results.

**Our Work (one box):**
- Title: "Our Work".
- Text: "Project examples will be added here as approved work is cleared for publication."
- No fake clients, logos, testimonials, awards, numbers or before-and-after pictures.

**What AULUCK does not promise (one box):**
- "No responsible agency can guarantee sales, rankings, viral reach or a specific return in every market. Results depend on the offer, audience, competition, budget, timing and many outside factors."

**Founder teaser (one box):**
- Small photo (or placeholder), name, one line, button "Read the founder's story" -> Founder page.

**Bottom:** Discuss Your Project button, enquiry form, footer.

---

## 8. Page 5 - Blogs

### 8.1 Top

- Title: "Blogs" (very large).
- Short intro: "Simple guides on marketing, branding, digital growth, AI, learning and career."
- Buttons: All (default) | Business | Education.
- Search bar: "Search articles". If nothing matches: "No articles match this selection. Try a different topic."

### 8.2 Layout

- One featured article at the top (large card with hologram image, tag, title, summary, "Read full").
- Then a grid of cards (3 per row on a computer, 2 on tablet, 1 on phone, plus a slider with arrows).
- Each card: hologram image, tag, title, one-line summary, "Read full".
- The box never gets cut off at the edge. Cards fit inside the screen width.

### 8.3 Read full pop-up

- Opens on the same page. It does not change the page.
- Top: a hologram picture and the article title.
- Middle: the full article text, with headings. It scrolls inside the pop-up.
- Close button (X) at the top right. Also closes with the Escape key.
- End of the pop-up: a button "View Pricing" (opens Pricing page) and a button "Enquire" (goes to the form).

### 8.4 Article list (19 drafts from the master copy)

Business tag:
1. Digital Marketing Strategy: A Practical Guide for Business
2. SEO for Businesses: How Search Visibility Is Built
3. Social Media Marketing: From Posting to Purpose
4. Paid Advertising vs Organic Marketing: Choosing the Right Mix
5. Brand Positioning: Helping Customers Understand Why You Matter
6. Consumer Psychology in Marketing: Understanding Decisions
7. The Business Growth Funnel: From Attention to Retention
8. Using AI in Marketing: Practical Workflows and Responsible Use
9. A Business Website That Supports Trust and Conversion
10. Offline Marketing in a Digital World
11. Influencer Marketing: Planning Creator Partnerships
12. Email and WhatsApp Marketing: Useful Communication, Not Noise
13. Local Business Visibility: Creating a Reliable Online Presence

Education tag (proposed, confirm in section 17):
14. Data Analytics for Better Business Decisions
15. Statistics for Everyday Business
16. Graphic Design for Business: Clarity Before Decoration
17. Video Content Strategy: Plan Stories Before You Press Record
18. Digital Skills and Career Learning: Building a Practical Foundation

Held back: "Podcast Marketing for Businesses" (see section 17).

Article author line: "AULUCK Knowledge Hub" (no person's name is invented). Article text comes only from the master copy drafts.

---

## 9. Page 6 - Pricing

This is the only page with prices.

### 9.1 Top

- Title: "Pricing" (very large).
- Short intro: "Starting prices for each service. Final price depends on scope and requirements."
- Small line: "Prices to be confirmed by AULUCK."
- Small line: "Ad spend, printing, media, domain, hosting and other third-party costs are separate unless your written quote includes them."

### 9.2 Three tier boxes

- Three boxes side by side: **Basic**, **Medium**, **Premium**.
- Each box lists services one per line, with that tier's price where the services list has one.
- Boxes stack on a phone. Text is never cut off.
- Services with one price only: how they show in the tier boxes is to be confirmed (section 17).

### 9.3 Services table (below)

- Title: "All services and prices".
- Buttons: All (default) | Business | Education.
- Under Business: Solutions | Marketing | Print Media | Branding.
- Under Education: Career | Help | Knowledge.
- Filter: Fixed price | Get Quote | All.
- Search bar.
- Table columns: Service | Price (or Get Quote tag) | Enquire button.
- Rows grouped by division and category, with the same names as the services list.
- First screen shows the first rows exactly as in the services list.

**Real counts:**
- 210 services in total (184 Business + 26 Education).
- 145 with a fixed starting price.
- 65 "Get Quote" (39 Business + 26 Education).

**Price examples (from the services list):**
- Business Website: From ₹20,000 (Basic ₹20,000, Medium ₹40,000, Premium ₹75,000+).
- Domain Setup: From ₹1,500.
- Lead Capture Systems: Get Quote.

Note: domain fee and hosting fee are separate unless quoted (shown under those rows).

### 9.4 Bottom

- Enquiry form (section 11.1), footer.

---

## 10. Page 7 - Founder

One main box with all the founder content inside it:

- Photo: Chirag's photo from the existing site, if it is found and approved. If not, a clear placeholder: "Photo to be added."
- Name: Chirag Auluck.
- Line: Founder of AULUCK.
- Headline: "The thinking behind AULUCK." (large).
- Short bio (only facts from the master copy): "Chirag Auluck is the founder of AULUCK. His work is shaped by an interest in how businesses are perceived, why people trust some brands more quickly than others and how strategy, creative communication and digital systems influence the customer journey."
- Second line: "AULUCK's philosophy brings together consumer psychology, premium positioning, digital trust systems, conversion behaviour and AI-enhanced execution."
- Hologram beside the photo (blue, violet, cyan).

Other parts on the page (inside the same box or stacked, not extra pages):
- Philosophy: Perception -> Trust -> Growth.
- Timeline: "Timeline to be added by Chirag."
- Verified work and official links: "To be added" (no links until real).
- Quote area: a quote only in Chirag's own words, once he sends them. Until then: "Quote to be added."
- CTA: "Discuss Your Project".
- Enquiry form and footer.

Rule: no years of experience, degrees, awards or clients are written unless Chirag gives them.

---

## 11. Shared parts (every page)

### 11.1 Enquiry form

Title: "Let's talk about your project." (or the course question on Education).

Fields:
1. Full name (required).
2. Business / organisation (optional).
3. Email (required; checked for a valid email).
4. Phone / WhatsApp (optional).
5. "I am enquiring about" (required): dropdown: Business (Solutions, Marketing, Print Media, Branding), Education (Career, Help, Knowledge), Pricing question, Other.
6. Project or course details (required, long text).
7. Preferred contact method (optional): Email, Phone, WhatsApp.
8. Privacy consent (required checkbox): "I agree that AULUCK may use the details provided to respond to this enquiry." With a link to the Privacy pop-up.
9. Button: "Submit Enquiry".

Not included: a budget field (not approved yet).

Messages:
- Sending: "Submitting your enquiry..."
- Success: "Thank you. Your enquiry has been received."
- Error: "We could not submit your enquiry. Please check the details or use the contact options on this page." (Show the call and WhatsApp buttons next to it.)
- Missing field: "Please complete this field."
- Missing consent: "Please confirm that you have read the Privacy Policy and agree to be contacted about this enquiry."

The success message shows only when the enquiry really went through.

### 11.2 Footer (one box, same on every page)

- AULUCK logo.
- One line: "AULUCK connects strategy, branding, digital marketing, technology and AI-enhanced execution to help businesses communicate their value with clarity and build a stronger digital presence."
- Page links: Home, Business, Education, About, Blogs, Pricing, Founder.
- Email: to be confirmed (section 17).
- Call and WhatsApp: +91 80596 74233.
- Social links: placeholders only ("Social links to be added"). No real links until confirmed.
- Small links: Terms | Privacy | Cookie | Accessibility. Each opens a pop-up on the same page.
- Copyright line.

Legal pop-up text comes from the master copy drafts. Any square-bracket placeholder (like a registered address) stays hidden until filled in.

### 11.3 Floating call / WhatsApp button

- Round button, bottom right, on every page, always in the same corner.
- Tap it: it opens two round options: Call (+91 80596 74233) and WhatsApp (+91 80596 74233).
- Closes when you tap outside it or tap the X.
- It never covers content:
  - On a computer it sits in the empty margin at the right.
  - On a phone it is small, and every page keeps a bottom space so the last line of text is never under it.
  - Services boxes, buttons, form fields and footer links are always fully visible.

### 11.4 Pop-ups

- Blog "Read full" pop-up (section 8.3).
- Legal pop-ups (Terms, Privacy, Cookie, Accessibility).
- Each has a clear X and closes with Escape.

---

## 12. Background, hologram and music

### 12.1 Background (creatures)

Only these four creatures, in deep black water:
- Betta fish
- Jellyfish
- Shark
- Whale

**Not allowed:** starfish, octopus, a ring creature, any other sea animal.

Rules:
- Shark and whale are solid and realistic, with a soft edge glow (not see-through ghosts).
- Betta and jellyfish are soft and light.
- The creatures swim slowly and loop without a visible jump.
- Background is dimmed behind the content. Text sits on dark panels so it is always easy to read.
- Strongest light at the edges, dark quiet area in the middle where text is.
- Blue outline glow appears on boxes only. The background has no ring.

Source: the approved creature background (19-20 Nov look), with the shark and whale in the solid, glowing version.

### 12.2 Moving hologram

- A glowing hologram in blue, violet and cyan. Gentle float and slight depth movement.
- Used on: Home hero, the centre cards of the Business, Education and All Services lists, Founder box, Blog card images and the featured blog.
- Never the letter H.
- Not spinning or flashing.

### 12.3 Background music (PROPOSAL - Chirag to confirm)

Proposal: the soft-bass background tune from the earlier final site (warm, slow, about 80 beats per minute, 432 Hz base). It is a synthesised sound loop, not an mp3 file.

- Sound is OFF when the page opens (browsers block sound until a tap anyway).
- A clear SOUND ON / SOUND OFF button in the header area.
- Volume slider.
- Fades in and out smoothly. Loops with no click at the join.
- Lowers itself a little when a pop-up opens.
- The choice (on or off, volume) is remembered on the same device.

This is a proposal only. Confirm or change in section 17.

---

## 13. Look: colours, fonts and headings

**Colours:**
- Black background: #050609
- Dark navy: #101522
- Surface boxes: #151A27
- Business blue: #168BFF
- Education purple: #9B5CFF
- Main text: #F4F5F7
- Secondary text: #B8BBC5
- Lines and borders: white or blue at 8-15% strength
- Pink, orange or gold: only as small hologram reflections, never big areas
- No rainbow gradients. No heavy neon outlines.

**Font:** Space Grotesk for everything (headings, text, buttons, form, footer). Font files are bundled with the site (regular, medium and bold). No online font link needed.

**Sizes (desktop):**
- AULUCK word (hero): very large (about 70 px).
- Page titles: 60-72 px, bold.
- Section titles (Business, Education, All Services, Our services, FAQ, Blogs): about 52 px, bold.
- Box titles: 28-34 px (about 30 px).
- Body text: 16-18 px.
- Small labels: 13-14 px.
- Buttons and menu: 15-16 px, bold.

**Sizes (phone):**
- Hero headline: 36-44 px.
- Section titles: 30-36 px.
- Body: 15-16 px.

**Readable text:** every heading and paragraph is visible from the start (no text that fades in from invisible). Text contrast is at least 4.5 to 1 against its background. Box text never sits on a moving image without a dark panel.

**Alignment:** one grid. Content width about 1200-1320 px on a computer, 32 px side margin on tablet, 20 px on phone. No sideways scroll on any page.

**Cards and boxes:** dark, opaque enough for text, with a soft blue border glow on hover (no shaking).

---

## 14. Images

- Logo: the official AULUCK logo file only.
- Other images (hologram art, founder photo, background images): taken from the existing website (https://jolly-palmier-d1534e.netlify.app/), where they exist and are approved for reuse.
- Where an image is missing, a clear placeholder is shown with a short label. No stock photos of random people, no fake client logos.
- Founder photo: Chirag's photo if found and approved; otherwise "Photo to be added".

---

## 15. Speed and motion rules

- The first screen shows quickly. Animation starts only after the page is ready.
- Images are small and load when they come close to the screen (lazy loading).
- Background animation pauses when the browser tab is hidden.
- On phones: fewer particles and lighter effects. Full-screen heavy effects are avoided.
- Reveal animations are gentle (fade and slight upward move, 500-800 ms). They never hide text forever: text is visible even if an animation does not run.
- Button and card hover: 250-350 ms soft change.
- Reduced motion (the phone or computer setting for less motion): the background and hologram show a still frame. Nothing shakes, spins or flashes. Everything still works.
- Navigation and key information never depend on animation.

---

## 16. Where each part's content comes from

| Part | Source |
|---|---|
| Hero line, short texts | Approved look (21 Nov) and master copy home section |
| Diagram structure and names | Approved diagram picture (21 Nov) and the page spec; category names checked against the services list |
| Services counts and rows | Services list PDF (184 Business, 26 Education) |
| Prices and Get Quote rows | Services list PDF (145 fixed prices, 65 Get Quote); price examples checked against it |
| Course hours | Services list PDF and SEO master plan (95+, 30, 20, 40, 40, 10, 10 hours; Graphic Designing to be confirmed) |
| About text | Master copy, About section (AULUCK story, philosophy, approach, what we don't promise) |
| Founder text | Master copy, Founder page (only the confirmed facts); SEO master plan founder section |
| Blogs | Master copy, 19 article drafts (titles and text) |
| FAQ | Master copy, FAQ section (with changes in section 17) |
| Enquiry form fields and messages | Master copy, contact section |
| Footer text and legal links | Master copy, global text section and legal drafts |
| Phone and WhatsApp | +91 80596 74233 (approved) |
| Email | To be confirmed (section 17) |
| Creature background | Approved creature background (19-20 Nov), shark and whale in the solid glowing version |
| Hologram | Approved look (20 Nov), with the hologram rule from the spec |
| Images | Existing website, approved images only |
| Music | Soft-bass tune from the earlier final site (proposal) |

---

## 17. Things Chirag needs to confirm (nothing goes live until then)

1. **Email address.** The approved spec says theauluck@gmail.com. The master copy says chiunaulcuk@gmail.com and asks to check the spelling. Which one is correct and monitored?
2. **Background music.** Yes to the soft-bass tune (sound OFF by default), or pick another.
3. **Single-price services in the tier boxes.** Services with only one price (or Get Quote) - which tier box should show them, or should they only show in the table? Confirm.
4. **Diagram branding names.** The diagram names Branding categories as Brand Strategy, Brand Identity, Guidelines, Brand Applications, Creative Direction. The services list uses Brand Strategy & Identity and Creative Design. Which names should the diagram use?
5. **Two diagram items not in the services list.** "Internships" (Career) and "Student Discounts" (Help) are in the approved diagram but not in the services list. Keep them in the diagram only, add them to the list, or remove them?
6. **Prices.** The services list has prices for most Business services. The master copy has an older AI Studio price table. This plan uses the services list. Confirm.
7. **FAQ changes.** (a) The podcast question is removed (no Podcast page in the 7 pages). (b) The "How is pricing decided?" answer is reworded to match the Pricing page. Confirm.
8. **Podcast article.** "Podcast Marketing for Businesses" is held back, since there is no Podcast page. Include it or not?
9. **Blog tags.** Business or Education tags are proposed in section 8.4. Confirm.
10. **Founder photo and details.** Photo, timeline, links, and quote come from Chirag. Until then, placeholders only.
11. **Social links.** Placeholders until real links are given.
12. **Legal text.** Terms, Privacy, Cookie and Accessibility need Chirag's and a legal check before publishing. Placeholders stay hidden.
13. **Course status.** Courses are shown with hours only. Fees, start dates, certificates and open enrolment stay hidden until confirmed.
14. **Phone number.** +91 80596 74233 is shown as the call and WhatsApp number. Confirm it is active.
15. **Music proposal.** The soft-bass loop is a proposal (section 12.3). Nothing about sound is final until Chirag says yes.

---

## 18. Checks before it goes live

Test each page at 1440, 1024, 930, 768 and 390 pixel widths:
- Nothing is cut off. Nothing runs off the right edge.
- Every heading and paragraph is visible, with good contrast.
- The floating button never covers a box, button, form field or footer link.
- The header shows the 7 links in the right order, with the right page highlighted.
- Background shows only betta, jellyfish, shark and whale. No starfish, octopus or ring.
- Reduced motion shows a still picture.
- Sound is off when the page opens.
- Prices appear on the Pricing page only.
- Every button goes somewhere real.

Full checklist: see CHECKLIST.md in the same folder.
