"""Builds assets/js/data.js for the AULUCK website (v2).

Sources (read only, never written):
  - Service rows: /workspace/agent/projects/aulick-all-services-2026-11-19/src/data.py
    (transcribed from AULUCK-All-Services.pdf; every price is taken from there).
  - Knowledge Hub article drafts: the master copy, section 'ARTICLE DRAFT' (19 drafts).

Price rule (same as the PDF):
  - Rows with Basic / Medium / Premium amounts show the three amounts.
  - Rows with a single 'From' amount show 'From <amount>' (the PDF wording, no extra '+').
  - Rows marked Get Quote show 'Get Quote'.
Run with:
    /opt/py/bin/python3 -I tools/make_data.py
"""
import json
import os
import re
import sys

SRC_DIR = '/workspace/agent/projects/aulick-all-services-2026-11-19/src'
MASTER = '/workspace/agent/projects/aulick-master-site-2026-11-16/source/master-copy.txt'
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, 'assets', 'js', 'data.js')

sys.path.insert(0, SRC_DIR)
from data import BUSINESS, EDUCATION, EDU_COURSES  # noqa: E402  (read-only import)



def short_excerpt(text, limit):
    """Cut at a whole word and add an ellipsis, never mid-word."""
    text = ' '.join(text.split())
    if len(text) <= limit:
        return text
    cut = text[:limit]
    if ' ' in cut:
        cut = cut[:cut.rfind(' ')]
    return cut.rstrip(' ,;:') + '...'

def row_prices(tiers):
    """Return (kind, values): kind 'quote' | 'tiers' | 'from'."""
    if tiers is None:
        return 'quote', None
    b, m, p = tiers
    if m or p:
        return 'tiers', [b, m, p]
    return 'from', 'From ' + b.rstrip('+')


def build_groups(raw, scope):
    depts = []
    for code, name, desc, cats in raw:
        categories = []
        for cat_id, group, cat_name, services in cats:
            rows = []
            for svc_name, note, tiers in services:
                kind, val = row_prices(tiers)
                rows.append({'n': svc_name, 'note': note or '', 'kind': kind, 'v': val})
            categories.append({'id': cat_id, 'group': group or cat_name, 'name': cat_name,
                               'services': rows})
        depts.append({'id': code, 'name': name, 'desc': desc, 'categories': categories,
                      'count': sum(len(c['services']) for c in categories)})
    return depts


DIVISIONS = build_groups(BUSINESS, 'business')
DEPTS = build_groups(EDUCATION, 'education')
TOTAL = sum(d['count'] for d in DIVISIONS)
EDU_TOTAL = sum(d['count'] for d in DEPTS)
FIXED = sum(1 for d in DIVISIONS for c in d['categories'] for s in c['services'] if s['kind'] != 'quote')
QUOTE = sum(1 for d in DIVISIONS for c in d['categories'] for s in c['services'] if s['kind'] == 'quote')
assert TOTAL == 184, TOTAL  # 184 Business rows in the PDF
assert EDU_TOTAL == 26, EDU_TOTAL  # 26 Education rows in the PDF
assert (FIXED, QUOTE) == (145, 39), (FIXED, QUOTE)  # PDF header: 145 with starting price, 39 Get Quote

COURSES = [{'n': n, 'd': d} for n, d in EDU_COURSES]

# Tabs use the approved names (diagram + spec).
BIZ_TABS = [{'label': 'All', 'filter': 'all'}] + [
    {'label': d['name'], 'filter': d['id']} for d in DIVISIONS]
EDU_TABS = [{'label': 'All', 'filter': 'all'}] + [
    {'label': d['name'], 'filter': d['id']} for d in DEPTS]
SCOPE_TABS = [
    {'label': 'All', 'filter': 'all'},
    {'label': 'Business', 'filter': 'business'},
    {'label': 'Education', 'filter': 'education'},
]

# Cluster and audience for each article draft, in the order the drafts appear in the master copy.
DRAFT_META = [
    ('Digital Marketing', 'business'), ('SEO', 'business'), ('Social Media', 'business'),
    ('Paid Advertising', 'business'), ('Branding', 'business'), ('Consumer Psychology', 'business'),
    ('Business Growth', 'business'), ('AI', 'business'), ('Web & E-Commerce', 'business'),
    ('Data Analytics', 'business'), ('Statistics', 'business'), ('Graphic Design', 'business'),
    ('Video & Content', 'business'), ('Education & Careers', 'education'), ('Podcast & Media', 'business'),
    ('Offline Marketing', 'business'), ('Influencer Marketing', 'business'),
    ('Email & WhatsApp', 'business'), ('Local Visibility', 'business'),
]
HUES = ['violet', 'blue', 'sunset', 'green', 'steel']
STOP_RE = re.compile(r'^\s*(1[3-9]|2[0-9]) / [A-Z]')  # next master-copy section heading
FOOTER_RE = re.compile(r'COMPLETE WEBSITE MASTER COPY|^\s*\d+ / 104\s*$')


def parse_drafts():
    raw = open(MASTER, encoding='utf-8').read().replace('\x0c', '\n').split('\n')
    starts = [i for i, l in enumerate(raw) if 'KNOWLEDGE HUB / ARTICLE DRAFT' in l]
    drafts = []
    for n, s in enumerate(starts):
        end = starts[n + 1] if n + 1 < len(starts) else len(raw)
        lines = []
        for l in raw[s + 1:end]:
            if STOP_RE.search(l):
                break
            if FOOTER_RE.search(l):
                continue
            lines.append(l.strip())
        url_i = next(i for i, l in enumerate(lines) if l.startswith('URL:'))
        title = ' '.join(l for l in lines[:url_i] if l).strip()
        # keep only the article body: stop before the SEO publishing fields and internal editorial note
        body_lines = lines[url_i + 1:]
        cut = next((i for i, l in enumerate(body_lines) if l.startswith('SEO publishing fields')), len(body_lines))
        body_lines = body_lines[:cut]
        # sections of the body: paragraphs are blank-line separated; a heading is a short line with no full stop
        blocks, cur = [], []
        for l in body_lines:
            if l == '':
                if cur:
                    blocks.append(cur)
                    cur = []
            else:
                cur.append(l)
        if cur:
            blocks.append(cur)
        items = []
        for blk in blocks:
            first = blk[0]
            if first.startswith('Primary topic') or first.startswith('Related topics'):
                continue
            if len(blk) > 0 and len(first) < 90 and not first.endswith(('.', '?', '!', ':', ';', ',')) and not first.startswith('['):
                items.append({'h': first})
                rest = ' '.join(blk[1:]).strip()
                if rest:
                    items.append({'p': rest})
            else:
                items.append({'p': ' '.join(blk).strip()})
        drafts.append({'title': title, 'url': '', 'items': items})
    return drafts


def build_blogs():
    drafts = parse_drafts()
    assert len(drafts) == len(DRAFT_META) == 19, (len(drafts), len(DRAFT_META))
    blogs = []
    for i, (d, (cluster, scope)) in enumerate(zip(drafts, DRAFT_META), start=1):
        body = d['items']
        blogs.append({'id': i, 'title': d['title'], 'cluster': cluster, 'scope': scope,
                      'hue': HUES[i % len(HUES)], 'body': body,
                      'excerpt': short_excerpt(next((b['p'] for b in body if 'p' in b), ''), 200)})
    # Held back until Chirag decides (confirm item 8): there is no Podcast page on the site.
    blogs = [b for b in blogs if not any(b['title'].startswith(h) for h in HELD_BACK)]
    for i, b in enumerate(blogs, start=1):
        b['id'] = i
    return blogs


HELD_BACK = ['Podcast Marketing for Businesses']
BLOGS = build_blogs()


def main():
    payload = {
        'divisions': DIVISIONS,
        'depts': DEPTS,
        'courses': COURSES,
        'bizTabs': BIZ_TABS,
        'eduTabs': EDU_TABS,
        'scopeTabs': SCOPE_TABS,
        'blogs': BLOGS,
        'counts': {'business': TOTAL, 'education': EDU_TOTAL, 'fixed': FIXED, 'quote': QUOTE},
    }
    text = ('// Generated by tools/make_data.py. Do not edit by hand.\n'
            '// Service rows: PDF All Services. Article drafts: master copy (Knowledge Hub).\n'
            'window.AULUCK_DATA = ' + json.dumps(payload, ensure_ascii=False, indent=1) + ';\n')
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, 'w', encoding='utf-8') as f:
        f.write(text)
    print('wrote', OUT, 'business', TOTAL, 'education', EDU_TOTAL, 'fixed', FIXED,
          'quote', QUOTE, 'blogs', len(BLOGS))


if __name__ == '__main__':
    main()
