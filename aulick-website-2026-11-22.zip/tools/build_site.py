"""Builds the 7 AULUCK website pages (v2) into the v2 folder root.

Pages: index (Home), business, education, about, blogs, pricing, founder.
Lists, sliders, diagram, pricing table and Knowledge Hub cards are filled in by assets/js/app.js
from assets/js/data.js. The FAQ is read from the master copy (section 22).

Run with:
    /opt/py/bin/python3 -I tools/build_site.py
"""
import html
import os
import re

from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MASTER = '/workspace/agent/projects/aulick-master-site-2026-11-16/source/master-copy.txt'
E = html.escape

NAV = [
    ('index.html', 'Home', 'home'),
    ('business.html', 'Business', 'business'),
    ('education.html', 'Education', 'education'),
    ('about.html', 'About', 'about'),
    ('blogs.html', 'Blogs', 'blogs'),
    ('pricing.html', 'Pricing', 'pricing'),
    ('founder.html', 'Founder', 'founder'),
]

SEARCH_LABEL = 'Search services'


def frame_style(src):
    # the glowing frame takes the image's own proportions, so no empty space shows around it
    with Image.open(os.path.join(ROOT, src)) as im:
        w, h = im.size
    return ' style="aspect-ratio:' + str(w) + '/' + str(h) + '"'


# ---------- FAQ from the master copy (section 22) ----------
FOOTER_RE = re.compile(r'COMPLETE WEBSITE MASTER COPY|\d+ / 104\s*$')


def parse_faq():
    raw = open(MASTER, encoding='utf-8').read().replace('\x0c', '\n').split('\n')
    s = next(i for i, l in enumerate(raw) if l.strip().startswith('22 / FAQ COPY'))
    e = next((i for i in range(s + 1, len(raw)) if re.match(r'^\s*23 / ', raw[i])), len(raw))
    lines = [l.strip() for l in raw[s + 1:e] if not FOOTER_RE.search(l)]
    pairs = []
    cur = None
    after_blank = True
    i = 0
    while i < len(lines):
        l = lines[i]
        if l == '':
            after_blank = True
            i += 1
            continue
        # a question is one or more lines (no blank between) that end with '?'
        q_end = None
        if after_blank:
            for j in range(i, min(i + 3, len(lines))):
                if lines[j] == '':
                    break
                if lines[j].endswith('?'):
                    q_end = j
                    break
        if q_end is not None:
            q = ' '.join(lines[i:q_end + 1])
            pairs.append([q, ''])
            cur = pairs[-1]
            after_blank = False
            i = q_end + 1
            continue
        if cur is not None:
            cur[1] = (cur[1] + ' ' + l).strip()
        after_blank = False
        i += 1
    pairs = [p for p in pairs if p[1]]
    assert 10 <= len(pairs) <= 20, len(pairs)
    return pairs


# Blueprint section 17, item 7: no Podcast question (there is no Podcast page), and the pricing answer
# is reworded to match the Pricing page. Other answers stay word-for-word from the master copy.
PRICING_FAQ_ANSWER = ('Starting prices are on the Pricing page. Services with a fixed starting price show it there, '
                      'and services that need a scope are marked Get Quote. Prices are to be confirmed by AULUCK. '
                      'Quotes depend on scope, deliverables, complexity, timeline and third-party costs.')
FAQ = []
for _q, _a in parse_faq():
    if 'podcast' in _q.lower():
        continue
    if _q.startswith('How is pricing decided'):
        _a = PRICING_FAQ_ANSWER
    FAQ.append([_q, _a])

# ---------- shared parts ----------
def head(title, desc):
    return (
        '<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n'
        '<meta name="viewport" content="width=device-width,initial-scale=1">\n'
        '<title>' + E(title) + '</title>\n'
        '<meta name="description" content="' + E(desc) + '">\n'
        '<link rel="icon" href="data:,">\n<link rel="stylesheet" href="assets/css/site.css">\n</head>\n'
    )


def header(page):
    links = ''
    for href, label, key in NAV:
        cur = ' aria-current="page"' if key == page else ''
        links += '<a href="' + href + '"' + cur + '>' + label + '</a>'
    return (
        '<a class="skip" href="#main">Skip to content</a>\n'
        '<header class="top"><div class="wrap"><div class="bar">'
        '<a class="logo" href="index.html" aria-label="AULUCK home"><img src="assets/img/logo-crop.jpg" alt="AULUCK logo" width="76" height="56"></a>'
        '<button class="menu-btn" type="button" aria-expanded="false" aria-controls="site-nav">Menu</button>'
        '<nav class="main" id="site-nav" aria-label="Main">' + links + '</nav>'
        '</div></div></header>\n'
    )


def footer():
    legal = ''.join('<button type="button" data-legal="' + k + '">' + t + '</button>' for k, t in [
        ('terms', 'Terms'), ('privacy', 'Privacy'), ('cookie', 'Cookie'), ('access', 'Accessibility')])
    pages = ''.join('<a href="' + h + '">' + t + '</a>' for h, t, _ in NAV)
    return (
        '<footer class="site"><div class="wrap">'
        '<div class="foot-grid">'
        '<div><a class="logo" href="index.html" aria-label="AULUCK home"><img src="assets/img/logo-crop.jpg" alt="AULUCK logo" width="76" height="56"></a>'
        '<p style="margin-top:14px;max-width:360px">AULUCK connects strategy, branding, digital marketing, technology and education so businesses can build trust and grow with clarity.</p></div>'
        '<div><h5>Pages</h5>' + pages + '</div>'
        '<div><h5>Contact</h5>'
        '<a data-tel href="tel:+918059674233">+91 80596 74233</a>'
        '<a data-wa href="https://wa.me/918059674233">WhatsApp</a>'
        '<p class="note" style="margin-top:12px">Social links: to be added</p></div>'
        '</div>'
        '<div class="legal-row"><span>&copy; AULUCK</span>' + legal + '</div>'
        '</div></footer>\n'
    )


def fab():
    return (
        '<div class="fab">\n'
        '<div class="fab-menu" id="fab-menu" hidden>'
        '<a data-tel href="tel:+918059674233">Call AULUCK</a>'
        '<a data-wa href="https://wa.me/918059674233">WhatsApp AULUCK</a>'
        '</div>\n'
        '<button class="fab-btn" type="button" aria-expanded="false" aria-controls="fab-menu" aria-label="Call or WhatsApp AULUCK">'
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M21 15.5a2 2 0 0 1-2 2H8l-5 4V6a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>'
        '</button></div>\n'
    )


def modal():
    return (
        '<div id="modal" class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title" hidden>'
        '<div class="modal-box"><div class="modal-top"><div id="modal-tag"></div>'
        '<button class="modal-x" type="button" aria-label="Close">&times;</button></div>'
        '<div class="modal-scroll" id="modal-scroll"><h2 id="modal-title"></h2><div id="modal-body"></div></div>'
        '<div class="modal-foot" id="modal-foot"></div></div></div>\n'
    )


def scripts():
    return (
        '<script src="assets/js/bg.js"></script>\n'
        '<script src="assets/js/config.js"></script>\n'
        '<script src="assets/js/data.js"></script>\n'
        '<script src="assets/js/app.js"></script>\n'
    )


def page(key, title, desc, body_html):
    return (
        head(title, desc) +
        '<body data-page="' + key + '">\n'
        '<canvas id="bg" aria-hidden="true"></canvas>\n'
        '<div class="shade" aria-hidden="true"></div>\n' +
        header(key) +
        '<main id="main">\n' + body_html + '\n</main>\n' +
        footer() + fab() + modal() + scripts() +
        '<noscript><p class="wrap" style="padding-top:20px">Some lists and the diagram need JavaScript. The main text of each page is still here.</p></noscript>\n'
        '</body>\n</html>\n'
    )


def hero(eyebrow, h1, lead, buttons, img, alt, pu=False, caption='', plain=False):
    # img=None means no picture on this page: the picture block is left out entirely.
    cap = ('<p class="note" style="margin-top:14px">' + E(caption) + '</p>') if caption else ''
    if not img:
        return (
            '<section class="hero"><div class="wrap hero-grid no-art"><div>'
            '<div class="eyebrow' + (' pu' if pu else '') + '">' + E(eyebrow) + '</div>'
            '<h1>' + h1 + '</h1>'
            '<p class="lead" style="margin-top:20px">' + lead + '</p>'
            '<div class="btn-row">' + buttons + '</div>' + cap +
            '</div></div></section>\n'
        )
    frame = 'plain-img' if plain else 'glow-frame' + (' pu' if pu else '')
    art = ('<figure class="hero-art ' + frame + '"' + frame_style(img) + '><img src="' + img + '" alt="' + E(alt) + '" decoding="async"></figure>')
    cap = ('<p class="note" style="margin-top:10px">' + E(caption) + '</p>') if caption else ''
    return (
        '<section class="hero"><div class="wrap hero-grid"><div>'
        '<div class="eyebrow' + (' pu' if pu else '') + '">' + E(eyebrow) + '</div>'
        '<h1>' + h1 + '</h1>'
        '<p class="lead" style="margin-top:20px">' + lead + '</p>'
        '<div class="btn-row">' + buttons + '</div>'
        '</div><div>' + art + cap + '</div></div></section>\n'
    )


def sec_head(eyebrow, title, text='', pu=False):
    return (
        '<div class="sec-head"><div class="eyebrow' + (' pu' if pu else '') + '">' + E(eyebrow) + '</div>'
        '<h2>' + title + '</h2>' + ('<p>' + text + '</p>' if text else '') + '</div>'
    )


def diagram(which):
    ring = 'ring-b' if which == 'business' else ('ring-e' if which == 'education' else '')
    note = ('Click AULUCK to open the next level. Click Business or Education to open that side. '
            'Show full diagram opens every level.')
    return (
        '<div class="dg ' + ring + '" data-dg="' + which + '">'
        '<div class="dg-bar"><div class="crumb">AULUCK</div><div class="dg-ctrl">'
        '<button type="button" data-dgc="fit">Fit to screen</button>'
        '<button type="button" data-dgc="out" aria-label="Zoom out">&minus;</button>'
        '<button type="button" data-dgc="in" aria-label="Zoom in">+</button>'
        '<button type="button" data-dgc="reset">Start again</button>'
        '<button type="button" data-dgc="all">Show full diagram</button>'
        '</div></div>'
        '<div class="dg-stage"><div class="dg-sizer"><div class="dg-canvas"></div></div></div>'
        '<p class="dg-note">' + note + '</p></div>\n'
    )


def ring_box(scope, inner):
    ring = 'ring-b' if scope == 'business' else 'ring-e'
    return '<div class="box ' + ring + '">' + inner + '</div>'


def svc(scope, mode, title, search_label, show_title=True):
    return (
        '<div class="svc" data-svc="' + scope + '" data-mode="' + mode + '">' +
        ('<h3>' + E(title) + '</h3>' if show_title else '') +
        '<div class="toolbar"><div class="svc-tabs-host seg"></div>'
        '<div class="search"><input type="search" aria-label="' + E(search_label) + '" placeholder="' + E(search_label) + '"></div></div>'
        '<p class="count"></p><div class="svc-host"></div></div>\n'
    )


def enquiry():
    legal_btn = ('<button type="button" data-legal="privacy" style="background:none;border:0;color:#7FB8FF;'
                 'text-decoration:underline;cursor:pointer;font:inherit;padding:0">Privacy notice</button>')
    return (
        '<section class="sec" id="enquiry"><div class="wrap">'
        + sec_head('Enquiry', 'Tell us what you are building.', 'We will review your brief and discuss a suitable scope. Nothing is booked from this form.') +
        '<div class="box">'
        '<form class="enq" novalidate>'
        '<div><label for="e-name">Name <span class="req">*</span></label><input class="field" id="e-name" name="name" required autocomplete="name"></div>'
        '<div><label for="e-email">Email <span class="req">*</span></label><input class="field" id="e-email" name="email" type="email" required autocomplete="email"></div>'
        '<div><label for="e-phone">Phone or WhatsApp</label><input class="field" id="e-phone" name="phone" type="tel" autocomplete="tel"></div>'
        '<div><label for="e-cat">Category</label><select class="field" id="e-cat" name="category">'
        '<option>Business services</option><option>Education</option><option>Not sure yet</option></select></div>'
        '<div class="full"><span class="note">Preferred contact</span><div class="radios" style="margin-top:8px">'
        '<label><input type="radio" name="contact" value="WhatsApp" checked> WhatsApp</label>'
        '<label><input type="radio" name="contact" value="Call"> Call</label>'
        '<label><input type="radio" name="contact" value="Email"> Email</label></div></div>'
        '<div class="full"><label for="e-details">Details</label><textarea class="field" id="e-details" name="details" rows="5"></textarea></div>'
        '<div class="full consent"><input type="checkbox" id="e-consent" name="consent" required>'
        '<label for="e-consent" style="margin:0">I agree that AULUCK may contact me about this enquiry. I have read the ' + legal_btn + '. <span class="req">*</span></label></div>'
        '<div class="full btn-row" style="margin-top:0"><button class="btn p" type="submit">Submit enquiry</button></div>'
        '<p class="form-status full" aria-live="polite"></p>'
        '<p class="enq-note full">Submitting opens WhatsApp with your details filled in. Press send there to reach AULUCK.</p>'
        '</form></div></div></section>\n'
    )


def faq_box():
    items = ''.join('<details class="faq"><summary>' + E(q) + '</summary><p>' + E(a) + '</p></details>' for q, a in FAQ)
    return (
        '<section class="sec" id="faq"><div class="wrap">' +
        sec_head('FAQ', 'Frequently asked questions') +
        '<div class="box">' + items + '</div></div></section>\n'
    )


def pricing_box():
    tiers = ''.join('<div class="box tier-box"><h3>' + t + '</h3><ul class="tier-list" data-tier="' + str(i) + '"></ul></div>'
                    for i, t in enumerate(['Basic', 'Medium', 'Premium']))
    return (
        '<div data-pricing>'
        '<div class="box">'
        '<div class="toolbar"><div class="seg p-scope" role="group" aria-label="Scope"></div>'
        '<div class="search"><input type="search" aria-label="Search prices" placeholder="Search services"></div></div>'
        '<div class="toolbar"><div class="seg p-div" role="group" aria-label="Division"></div></div>'
        '<div class="toolbar"><div class="seg p-price" role="group" aria-label="Price type"></div></div>'
        '<p class="count"></p></div>'
        '<div class="tier-grid">' + tiers + '</div>'
        '<div class="box" style="margin-top:var(--gap)"><h3>Starting prices and Get Quote services</h3>'
        '<div class="table-wrap" style="margin-top:14px"><table><thead><tr><th>Service</th><th>Division and category</th><th>Price</th><th><span class="sr">Enquire</span></th></tr></thead>'
        '<tbody></tbody></table></div></div>'
        '<p class="svc-note">Prices to be confirmed by AULUCK.</p></div>\n'
    )


def btn(href, label, cls='p'):
    return '<a class="btn ' + cls + '" href="' + href + '">' + E(label) + '</a>'


def btn_button(label, attr, cls='s'):
    return '<button type="button" class="btn ' + cls + '" ' + attr + '>' + E(label) + '</button>'


# ---------- pages ----------
def home():
    h1 = 'We don&rsquo;t build brands. <span class="grad">We engineer authority.</span>'
    lead = ('AULUCK brings strategy, marketing, technology, print media, branding and education together under one connected brand.')
    body = ('<section class="hero"><div class="wrap hero-grid no-art"><div>'
            '<div class="brand-big">AULUCK</div>'
            '<div class="eyebrow">DIGITAL MARKETING INNOVATION</div>'
            '<h1>' + h1 + '</h1>'
            '<p class="lead" style="margin-top:20px">' + lead + '</p>'
            '<div class="btn-row">' + btn('#enquiry', 'Discuss Your Project') + btn('#services', 'View Pricing', 's') + '</div>'
            '<div class="chips"><a class="chip b" href="#structure">Business - 4 divisions</a>'
            '<a class="chip e" href="#structure">Education - Career, Help, Knowledge</a></div>'
            '<p class="note" style="margin-top:14px">' + E('Strategy first. Clear positioning. Connected execution. Measurable learning.') + '</p>'
            '</div></div></section>\n')
    body += ('<section class="sec" id="structure"><div class="wrap">' +
             sec_head('How AULUCK is organised', 'One AULUCK, two branches.',
                      'Business and Education, each with its divisions and categories. Full service lists are below.') +
             diagram('both') + '</div></section>\n')
    body += ('<section class="sec" id="business"><div class="wrap">' +
             ring_box('business', '<div class="sec-head"><h2>Business</h2><p>Four divisions. 184 services.</p></div>' +
                      svc('business', 'slider', 'Business services', 'Search Business services', show_title=False)) +
             '</div></section>\n')
    body += ('<section class="sec" id="education"><div class="wrap">' +
             ring_box('education', '<div class="sec-head"><h2>Education</h2><p>Three groups. 26 services.</p></div>' +
                      svc('education', 'slider', 'Education services', 'Search Education services', show_title=False)) +
             '</div></section>\n')
    body += ('<section class="sec"><div class="wrap">' +
             '<div class="box ring-e"><div class="founder-grid" style="gap:28px;grid-template-columns:1fr">'
                          '<div><div class="eyebrow pu">Founder</div><h2>Chirag Auluck</h2>'
             '<p style="margin-top:12px">Chirag Auluck is the founder of AULUCK. His work is shaped by an interest in how businesses are perceived, '
             'why people trust some brands more quickly than others and how strategy, creative communication and digital systems influence the customer journey.</p>'
             '<div class="btn-row">' + btn('founder.html', 'Read about Chirag', 'p') + '</div></div>'
             '</div></div></div></section>\n')
    body += ('<section class="sec" id="blogs"><div class="wrap">' +
             '<div class="box ring-b" data-blogs data-mode="slider">' +
             sec_head('Blogs', 'Blogs', 'Articles on marketing, branding, AI and learning. These are drafts, to be reviewed before they are published.') +
             '<div class="toolbar"><div class="blog-tabs seg"></div>'
             '<div class="search"><input type="search" aria-label="Search articles" placeholder="Search articles"></div></div>'
             '<p class="count"></p><div class="blog-host"></div></div></div></section>\n')
    body += ('<section class="sec" id="services"><div class="wrap">' +
             '<div class="box">' +
             sec_head('All services', 'All Services',
                      'Business and Education in one box. Two services show at a time. Slide, search or filter to see more. Prices are on the Pricing page.') +
             svc('all', 'slider', '', 'Search all services', show_title=False) +
             '</div></div></section>\n')
    body += enquiry()
    body += faq_box()
    return page('home', 'AULUCK | Digital Marketing, Branding, AI & Growth Solutions',
                'AULUCK connects strategy, branding, digital marketing, technology, AI and creative execution to help businesses build trust and grow with clarity.', body)


def business():
    body = hero('Business', 'Business services for clear, trusted growth.',
                'Solutions, marketing, print media and branding, arranged the way the work is delivered. Open each level in the diagram, or search the full list.',
                btn('#enquiry', 'Discuss Your Project') + btn('pricing.html', 'View Pricing', 's'),
                None, '')
    body += ('<section class="sec" id="services"><div class="wrap"><div class="box ring-b">' +
             sec_head('Business structure', 'Business, step by step.',
                      'Click AULUCK or Business to open the next level. Below the diagram, every service is listed under its division and category.') +
             diagram('business') +
             svc('business', 'list', 'Full list of business services', 'Search Business services') +
             '</div></div></section>\n')
    body += enquiry() + faq_box()
    return page('business', 'Business services | AULUCK',
                'Business services by AULUCK: solutions, marketing, print media and branding.', body)


def education():
    body = hero('Education', 'Learn skills that connect to real work.',
                'Career guidance, student help and professional courses. Open each level in the diagram, or search the full list.',
                btn('#enquiry', 'Discuss Your Project') + btn('pricing.html', 'View Pricing', 's'),
                None, '', pu=True)
    body += ('<section class="sec" id="services"><div class="wrap"><div class="box ring-e">' +
             sec_head('Education structure', 'Education, step by step.',
                      'Career, Help and Knowledge, with the categories under each one. Courses and hours are listed below the diagram.', pu=True) +
             diagram('education') +
             '<div style="margin-top:28px"><h3>Courses and hours</h3>'
             '<p class="note" style="margin-top:6px">Hours are from the plan. Prices are on the Pricing page.</p>'
             '<div class="course-grid" id="course-grid"></div></div>' +
             svc('education', 'list', 'Full list of education services', 'Search Education services') +
             '</div></div></section>\n')
    body += enquiry() + faq_box()
    return page('education', 'Education | AULUCK',
                'Education by AULUCK: career guidance, student help and professional courses.', body)


def about():
    body = hero('About AULUCK', 'A clearer system for how your business is seen, trusted and chosen.',
                'AULUCK is a digital marketing and growth-focused brand built around one central idea: businesses need more than isolated marketing activities. They need a clear position in the market, a credible identity, a useful digital experience and a consistent way to reach and serve customers.',
                btn('#enquiry', 'Discuss Your Project') + btn('business.html', 'Explore the solutions', 's'),
                None, '', pu=True)
    body += ('<section class="sec"><div class="wrap"><div class="box ring-b">' +
             sec_head('The AULUCK philosophy', 'Perception, trust, growth.',
                      'People form expectations from the signals a business sends: its name, visuals, website, content, responsiveness, proof and customer experience. AULUCK starts by understanding those signals and improving the system behind them.') +
             '<div class="phil"><span>Perception</span><em>&rarr;</em><span>Trust</span><em>&rarr;</em><span>Growth</span></div>'
             '<h3 style="margin-top:28px">What guides our work</h3>'
             '<ul class="list">'
             '<li><b style="color:#fff">Consumer psychology:</b> understand attention, perception, decision-making and customer context.</li>'
             '<li><b style="color:#fff">Premium brand positioning:</b> clarify what the business should be known for and why it matters.</li>'
             '<li><b style="color:#fff">Digital trust systems:</b> align the website, message, content and customer touchpoints.</li>'
             '<li><b style="color:#fff">Conversion optimisation:</b> reduce friction and make the next action understandable.</li>'
             '<li><b style="color:#fff">AI-enhanced execution:</b> use relevant tools to improve production and workflows, with human review.</li>'
             '</ul>'
             '<h3 style="margin-top:28px">What AULUCK does not promise</h3>'
             '<p style="margin-top:10px">No responsible agency can guarantee sales, rankings, viral reach or a specific return in every market. Results depend on the offer, audience, competition, budget, timing, implementation and many external factors.</p>'
             '</div></div></section>\n')
    body += ('<section class="sec"><div class="wrap">' +
             sec_head('Our approach', 'Discover, define, build, distribute, optimise.',
                      'These are planning stages, not guaranteed delivery dates. A schedule is agreed after the brief, scope and approvals are understood.') +
             '<div class="steps">'
             '<div class="step"><b>Discover</b><p>Understand goals, audience, offer, competitors, current assets and constraints.</p></div>'
             '<div class="step"><b>Define</b><p>Set positioning, message, deliverables, responsibilities and measures.</p></div>'
             '<div class="step"><b>Build</b><p>Create agreed brand, content, website, campaigns or systems.</p></div>'
             '<div class="step"><b>Distribute</b><p>Launch or publish through agreed channels.</p></div>'
             '<div class="step"><b>Optimise</b><p>Review performance evidence and improve bottlenecks.</p></div>'
             '</div></div></section>\n')
    body += ('<section class="sec"><div class="wrap box-grid">'
             '<div class="box ring-b"><div class="eyebrow">How the two branches connect</div><h3>Business and Education</h3>'
             '<p style="margin-top:12px">AULUCK has two branches. Business services are for companies. Education is for students and learners. Both use the same way of working.</p></div>'
             '<div class="box ring-e"><div class="eyebrow pu">Our work</div><h3>Selected work</h3>'
             '<p style="margin-top:12px"><span class="ph">Our Work: to be added</span></p>'
             '<p class="note" style="margin-top:12px">Only genuine work will be shown here. Results are added only when AULUCK has verified evidence.</p></div>'
             '</div></section>\n')
    body += enquiry() + faq_box()
    return page('about', 'About AULUCK | Strategy, Branding and Digital Growth',
                'Learn about AULUCK’s connected approach to brand positioning, digital marketing, technology, AI and business growth.', body)


def blogs():
    body = hero('Blogs', 'Blogs',
                'These articles are drafts. AULUCK will review each one before it is published. Read opens the article on this page.',
                btn('#blog-list', 'Read the articles') + btn('pricing.html', 'View Pricing', 's'),
                None, '')
    body += ('<section class="sec" id="blog-list"><div class="wrap"><div class="box ring-b" data-blogs data-mode="grid">'
             '<div class="toolbar"><div class="blog-tabs seg"></div>'
             '<div class="search"><input type="search" aria-label="Search articles" placeholder="Search articles"></div></div>'
             '<p class="count"></p><div class="blog-host"></div></div></div></section>\n')
    body += enquiry() + faq_box()
    return page('blogs', 'Blogs | AULUCK', 'Articles from AULUCK on digital marketing, branding, AI, data and learning. Drafts for review.', body)


def pricing():
    body = hero('Pricing', 'Prices',
                'Services with Basic, Medium and Premium prices are in three boxes. Services with a starting price or Get Quote are in the table below. Prices to be confirmed by AULUCK.',
                btn('#enquiry', 'Discuss Your Project') + btn('#price-list', 'See the list', 's'),
                None, '')
    body += ('<section class="sec" id="price-list"><div class="wrap">' + pricing_box() + '</div></section>\n')
    body += enquiry() + faq_box()
    return page('pricing', 'Pricing | AULUCK', 'Services and prices from AULUCK. Starting prices and Get Quote services. Prices to be confirmed by AULUCK.', body)


def founder():
    body = hero('Founder', 'The thinking behind AULUCK.',
                'Chirag Auluck is the founder of AULUCK. His work is shaped by an interest in how businesses are perceived, why people trust some brands more quickly than others and how strategy, creative communication and digital systems influence the customer journey.',
                btn('#enquiry', 'Discuss Your Project') + btn('about.html', 'About AULUCK', 's'),
                'assets/img/founder-chirag.webp', 'Placeholder drawing until a clear photo of Chirag Auluck is added.', plain=True,
                caption='Placeholder for now. A clear photo of Chirag will replace it.')
    body += ('<section class="sec"><div class="wrap"><div class="box ring-e">'
             '<div class="eyebrow pu">Philosophy</div><h3>Consumer psychology, premium positioning, digital trust.</h3>'
             '<p style="margin-top:12px">AULUCK’s philosophy brings together consumer psychology, premium positioning, digital trust systems, conversion behaviour and AI-enhanced execution. The focus is to help businesses communicate their value with greater clarity and build a more coherent digital presence.</p>'
             '<div class="quote-area">Quote to be added by Chirag.</div>'
             '<h3 style="margin-top:28px">Profile</h3>'
             '<p style="margin-top:10px"><span class="ph">Founder bio, background and timeline: to be added by Chirag.</span></p>'
             '<p class="note" style="margin-top:14px">No credentials or years of experience are shown until Chirag confirms them.</p>'
             '<div class="btn-row">' + btn('#enquiry', 'Talk to AULUCK', 'p') + '</div>'
             '</div></div></section>\n')
    body += enquiry() + faq_box()
    return page('founder', 'Chirag Auluck | Founder of AULUCK',
                'Meet Chirag Auluck, founder of AULUCK, and learn about the thinking behind its approach to positioning, trust and digital growth.', body)


PAGES = {
    'index.html': home,
    'business.html': business,
    'education.html': education,
    'about.html': about,
    'blogs.html': blogs,
    'pricing.html': pricing,
    'founder.html': founder,
}


def main():
    for name, fn in PAGES.items():
        text = fn()
        with open(os.path.join(ROOT, name), 'w', encoding='utf-8') as f:
            f.write(text)
        print('wrote', name, len(text))
    print('faq items', len(FAQ))


if __name__ == '__main__':
    main()
